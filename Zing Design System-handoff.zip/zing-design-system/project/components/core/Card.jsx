import React from 'react';

/**
 * Zing Card — white, pillowy, soft brand-tinted shadow, no hard border.
 * The workhorse container for everything: profiles, sessions, stats.
 */
export function Card({
  children,
  tone = 'plain',
  padding = 20,
  radius = 'var(--radius-xl)',
  interactive = false,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);

  const tones = {
    plain: { background: 'var(--surface-card)', border: 'none' },
    mint: { background: 'var(--surface-mint)', border: 'none' },
    sky: { background: 'var(--surface-sky)', border: 'none' },
    sunken: { background: 'var(--surface-sunken)', border: 'none' },
    outline: { background: 'var(--surface-card)', border: '1.5px solid var(--border-subtle)' },
  };
  const t = tones[tone] || tones.plain;

  return (
    <div
      onClick={onClick}
      onPointerDown={() => interactive && setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      style={{
        borderRadius: radius,
        padding,
        boxShadow: tone === 'sunken' ? 'none' : 'var(--shadow-card)',
        cursor: interactive ? 'pointer' : 'default',
        transform: pressed ? 'scale(0.985)' : 'scale(1)',
        transition: 'transform var(--dur-fast) var(--ease-out)',
        ...t,
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}

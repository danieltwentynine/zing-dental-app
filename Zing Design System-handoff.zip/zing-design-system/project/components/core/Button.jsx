import React from 'react';

/**
 * Zing Button — the primary tappable action.
 * Big, pillowy (16px radius), 56px tall, Nunito ExtraBold label.
 * Press = scale 0.96 + slight opacity (touch product). Disabled = 50% opacity.
 */
export function Button({
  children,
  label,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  loading = false,
  disabled = false,
  icon = null,
  iconRight = null,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);
  const isDisabled = disabled || loading;
  const content = children ?? label;

  const sizes = {
    sm: { height: 44, padding: '0 18px', font: 15, radius: 'var(--radius-md)' },
    md: { height: 56, padding: '0 24px', font: 18, radius: 'var(--radius-lg)' },
    lg: { height: 64, padding: '0 32px', font: 20, radius: 'var(--radius-xl)' },
  };
  const s = sizes[size] || sizes.md;

  const variants = {
    primary: {
      background: 'var(--brand-primary)',
      color: 'var(--text-on-brand)',
      boxShadow: pressed ? 'none' : 'var(--shadow-mint)',
      border: 'none',
    },
    secondary: {
      background: 'var(--brand-secondary)',
      color: 'var(--text-on-brand)',
      boxShadow: pressed ? 'none' : 'var(--shadow-sky)',
      border: 'none',
    },
    soft: {
      background: 'var(--surface-mint)',
      color: 'var(--mint-700)',
      boxShadow: 'none',
      border: 'none',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--brand-primary)',
      boxShadow: 'none',
      border: 'none',
    },
    outline: {
      background: 'var(--surface-card)',
      color: 'var(--text-primary)',
      boxShadow: 'none',
      border: '1.5px solid var(--border-subtle)',
    },
  };
  const v = variants[variant] || variants.primary;

  return (
    <button
      type="button"
      onClick={isDisabled ? undefined : onClick}
      disabled={isDisabled}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        width: fullWidth ? '100%' : 'auto',
        height: s.height,
        padding: s.padding,
        borderRadius: s.radius,
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: s.font,
        lineHeight: 1,
        cursor: isDisabled ? 'not-allowed' : 'pointer',
        opacity: isDisabled ? 0.5 : 1,
        transform: pressed && !isDisabled ? 'scale(0.96)' : 'scale(1)',
        transition: 'transform var(--dur-fast) var(--ease-bounce), box-shadow var(--dur-base) var(--ease-out)',
        WebkitTapHighlightColor: 'transparent',
        ...v,
        ...style,
      }}
      {...rest}
    >
      {loading ? <Spinner /> : icon}
      {!loading && content}
      {!loading && iconRight}
    </button>
  );
}

function Spinner() {
  return (
    <span
      aria-label="loading"
      style={{
        width: 20,
        height: 20,
        borderRadius: '50%',
        border: '2.5px solid rgba(255,255,255,0.45)',
        borderTopColor: '#fff',
        display: 'inline-block',
        animation: 'zing-spin 0.7s linear infinite',
      }}
    />
  );
}

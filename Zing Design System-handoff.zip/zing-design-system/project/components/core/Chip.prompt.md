Selectable pill — used for choices like a child's age or list filters. Mint-fills when selected.

```jsx
<Chip label="Age 6" selected={age === 6} onClick={() => setAge(6)} />
```

44px minimum tap target. `selected` switches to mint fill + glow.

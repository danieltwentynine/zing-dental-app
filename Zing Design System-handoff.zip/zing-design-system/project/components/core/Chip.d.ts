import React from 'react';

export interface ChipProps {
  label?: string;
  children?: React.ReactNode;
  selected?: boolean;
  icon?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** Selectable pill for single/multi choices (age, filters). 44px+ tap target. */
export function Chip(props: ChipProps): JSX.Element;

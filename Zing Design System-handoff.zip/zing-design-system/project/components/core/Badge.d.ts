import React from 'react';

export interface BadgeProps {
  label?: string;
  children?: React.ReactNode;
  /** Color family. */
  tone?: 'mint' | 'sky' | 'sunny' | 'coral' | 'grape' | 'warning' | 'neutral';
  /** Solid fill instead of soft tint. */
  solid?: boolean;
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Small status / reward pill. */
export function Badge(props: BadgeProps): JSX.Element;

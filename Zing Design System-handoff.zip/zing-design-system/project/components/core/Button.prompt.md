The primary tappable action in Zing — big, pillowy (16px radius), 56px tall, Nunito ExtraBold label. Use a contextual active-verb label and never "Submit"/"OK"/"Cancel".

```jsx
<Button label="Start brushing" onClick={start} />
<Button label="See results" variant="secondary" fullWidth />
<Button label="Try again" variant="soft" size="sm" />
<Button label="Log in" variant="ghost" />
```

Variants: `primary` (mint, glow shadow), `secondary` (sky), `soft` (mint wash), `ghost` (text-only), `outline` (bordered). Sizes: `sm` 44px, `md` 56px (default), `lg` 64px. Supports `icon`, `iconRight`, `loading`, `disabled`, `fullWidth`. Press feedback is a scale-to-0.96 pop on `--ease-bounce`.

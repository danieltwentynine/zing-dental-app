Pillowy white container with a soft brand-tinted shadow and big rounding — the workhorse surface across Zing.

```jsx
<Card>
  <h3>Today's brushing</h3>
  <p>Two great sessions so far!</p>
</Card>
<Card tone="mint" interactive onClick={open}>…</Card>
```

Tones: `plain` (white, default), `mint`/`sky` (soft wash), `sunken` (grey, no shadow — for nested wells), `outline` (hairline border). Set `interactive` for a press-scale on tap.

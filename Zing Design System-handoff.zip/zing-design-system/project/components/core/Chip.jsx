import React from 'react';

/**
 * Zing Chip — a selectable pill, e.g. choosing a child's age or a filter.
 * Big tap target, mint-fill when selected.
 */
export function Chip({ children, label, selected = false, icon = null, onClick, style = {}, ...rest }) {
  const [pressed, setPressed] = React.useState(false);
  const content = children ?? label;
  return (
    <button
      type="button"
      onClick={onClick}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      aria-pressed={selected}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        minHeight: 44,
        padding: '0 18px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 15,
        cursor: 'pointer',
        color: selected ? 'var(--text-on-brand)' : 'var(--text-primary)',
        background: selected ? 'var(--brand-primary)' : 'var(--surface-card)',
        border: selected ? '1.5px solid var(--brand-primary)' : '1.5px solid var(--border-subtle)',
        boxShadow: selected ? 'var(--shadow-mint)' : 'none',
        transform: pressed ? 'scale(0.95)' : 'scale(1)',
        transition: 'transform var(--dur-fast) var(--ease-bounce), background var(--dur-base), box-shadow var(--dur-base)',
        WebkitTapHighlightColor: 'transparent',
        ...style,
      }}
      {...rest}
    >
      {icon}
      {content}
    </button>
  );
}

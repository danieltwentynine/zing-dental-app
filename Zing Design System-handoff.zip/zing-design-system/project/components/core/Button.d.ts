import React from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'soft' | 'ghost' | 'outline';
export type ButtonSize = 'sm' | 'md' | 'lg';

/**
 * The primary tappable action in Zing. Always use a contextual, active-verb
 * label ("Start brushing", "See results") — never "Submit"/"OK"/"Cancel".
 *
 * @startingPoint section="Core" subtitle="Pillowy primary action button" viewport="700x430"
 */
export interface ButtonProps {
  /** Button text (or pass children). */
  label?: string;
  children?: React.ReactNode;
  /** primary = mint, secondary = sky, soft = mint-wash, ghost = text-only, outline = bordered. */
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  loading?: boolean;
  disabled?: boolean;
  /** Leading icon node (e.g. a Phosphor <i>). */
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;

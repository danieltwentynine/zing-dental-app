Small rounded status or reward pill.

```jsx
<Badge tone="mint" label="Brushed today" />
<Badge tone="sunny" solid label="Perfect!" />
<Badge tone="warning" label="Missed zones" />
```

Tones: `mint` `sky` `sunny` `coral` `grape` `warning` `neutral`. `solid` swaps the soft tint for a filled pill. Pass an `icon` node to lead with a Phosphor glyph.

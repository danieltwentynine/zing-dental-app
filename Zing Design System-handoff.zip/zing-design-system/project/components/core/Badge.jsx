import React from 'react';

/**
 * Zing Badge — small status/reward pill. Two looks:
 *  - tone pills for status (mint/sky/sunny/coral/warning/neutral)
 *  - reward badge tiers for kids' achievements.
 */
export function Badge({ children, label, tone = 'mint', icon = null, solid = false, style = {}, ...rest }) {
  const map = {
    mint: ['var(--mint-600)', 'var(--mint-100)', 'var(--mint-500)'],
    sky: ['var(--sky-600)', 'var(--sky-100)', 'var(--sky-400)'],
    sunny: ['#9a7b12', 'var(--sunny-100)', 'var(--sunny-500)'],
    coral: ['#b23a47', 'var(--coral-100)', 'var(--coral-500)'],
    grape: ['#5c4fb5', 'var(--grape-100)', 'var(--grape-500)'],
    warning: ['#9a6418', 'var(--warning-100)', 'var(--warning-500)'],
    neutral: ['var(--ink-600)', 'var(--ink-100)', 'var(--ink-400)'],
  };
  const [fg, bg, solidBg] = map[tone] || map.mint;
  const content = children ?? label;

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 26,
        padding: '0 12px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 13,
        lineHeight: 1,
        color: solid ? '#fff' : fg,
        background: solid ? solidBg : bg,
        whiteSpace: 'nowrap',
        ...style,
      }}
      {...rest}
    >
      {icon}
      {content}
    </span>
  );
}

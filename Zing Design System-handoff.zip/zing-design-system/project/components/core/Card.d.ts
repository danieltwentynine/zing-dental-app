import React from 'react';

/**
 * Pillowy white container with a soft brand-tinted shadow — the workhorse
 * surface for profiles, sessions and stats.
 *
 * @startingPoint section="Core" subtitle="Pillowy content card" viewport="700x430"
 */
export interface CardProps {
  children?: React.ReactNode;
  /** plain (white), mint/sky wash, sunken (sunken grey, no shadow), outline. */
  tone?: 'plain' | 'mint' | 'sky' | 'sunken' | 'outline';
  padding?: number;
  radius?: string;
  /** Adds a gentle press-scale; pair with onClick. */
  interactive?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export function Card(props: CardProps): JSX.Element;

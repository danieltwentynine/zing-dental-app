import React from 'react';

export const ALL_ZONES: string[];

export type ZoneState = 'empty' | 'active' | 'done' | 'missed';

/**
 * The signature Zing component: a stylized 10-zone dental arch that fills as
 * the child brushes. Zones animate smoothly; missed zones show warm orange,
 * never red.
 *
 * @startingPoint section="Brushing" subtitle="10-zone brushing mouth map" viewport="700x340"
 */
export interface MouthMapProps {
  /** Map of ToothZone -> state. Missing zones default to 'empty'. */
  states?: Record<string, ZoneState>;
  size?: number;
  /** Overlay tiny zone-name labels (debug). */
  showLabels?: boolean;
  style?: React.CSSProperties;
}

export function MouthMap(props: MouthMapProps): JSX.Element;

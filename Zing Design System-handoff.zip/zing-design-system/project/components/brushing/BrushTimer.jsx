import React from 'react';

/**
 * BrushTimer — the 2-minute brushing countdown. A big mint progress ring with
 * Space Grotesk numerals in the center. Purely presentational: pass the
 * remaining seconds; drive it from the session state machine.
 */
export function BrushTimer({ remaining = 120, total = 120, label = '', size = 240, style = {} }) {
  const r = size / 2 - 14;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, 1 - remaining / total));
  const mm = Math.floor(remaining / 60);
  const ss = String(Math.floor(remaining % 60)).padStart(2, '0');

  return (
    <div style={{ position: 'relative', width: size, height: size, ...style }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--ink-100)" strokeWidth="14" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--brand-primary)"
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: 'stroke-dashoffset 1s linear' }}
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 2,
        }}
      >
        <span
          style={{
            fontFamily: 'var(--font-numeric)',
            fontWeight: 700,
            fontSize: size * 0.26,
            color: 'var(--text-primary)',
            lineHeight: 1,
            letterSpacing: '-0.02em',
          }}
        >
          {mm}:{ss}
        </span>
        {label && (
          <span style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, color: 'var(--text-secondary)' }}>
            {label}
          </span>
        )}
      </div>
    </div>
  );
}

The 2-minute brushing countdown — a mint progress ring with Space Grotesk numerals in the center. Presentational; drive `remaining` from the session state machine.

```jsx
<BrushTimer remaining={86} total={120} label="Brush your top teeth" />
```

The ring fills (and depletes the count) as the session progresses.

import React from 'react';

/**
 * MouthMap — the signature Zing component. A stylized dental arch (occlusal
 * view) of 10 zones that fill as the child brushes. This is the design-system
 * recreation of the app's live camera overlay (CLAUDE.md > MouthMap.tsx).
 *
 * Zone states: 'empty' (grey) → 'active' (light mint, brushing now) →
 * 'done' (solid mint + check). At session end, un-brushed zones show 'missed'
 * (warm orange — never red).
 */
export const ALL_ZONES = [
  'top-back-left', 'top-left', 'top-front', 'top-right', 'top-back-right',
  'bottom-back-left', 'bottom-left', 'bottom-front', 'bottom-right', 'bottom-back-right',
];

const STATE_FILL = {
  empty: 'var(--zone-empty)',
  active: 'var(--zone-active)',
  done: 'var(--zone-done)',
  missed: 'var(--zone-missed)',
};

function polar(cx, cy, r, deg) {
  const a = (deg * Math.PI) / 180;
  return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
}

function sectorPath(cx, cy, ri, ro, a0, a1) {
  const [x0o, y0o] = polar(cx, cy, ro, a0);
  const [x1o, y1o] = polar(cx, cy, ro, a1);
  const [x1i, y1i] = polar(cx, cy, ri, a1);
  const [x0i, y0i] = polar(cx, cy, ri, a0);
  return `M ${x0o} ${y0o} A ${ro} ${ro} 0 0 1 ${x1o} ${y1o} L ${x1i} ${y1i} A ${ri} ${ri} 0 0 0 ${x0i} ${y0i} Z`;
}

export function MouthMap({ states = {}, size = 220, showLabels = false, style = {} }) {
  const cx = 110, cy = 110, ro = 96, ri = 50;
  // Upper arch across the TOP (angles 200°..340°), lower arch across BOTTOM (20°..160°).
  const upper = ALL_ZONES.slice(0, 5);
  const lower = ALL_ZONES.slice(5);
  const gap = 3; // degrees between teeth

  const buildArc = (zones, startDeg, endDeg) => {
    const span = (endDeg - startDeg) / zones.length;
    return zones.map((z, i) => {
      const a0 = startDeg + i * span + gap / 2;
      const a1 = startDeg + (i + 1) * span - gap / 2;
      const st = states[z] || 'empty';
      const mid = (a0 + a1) / 2;
      const [lx, ly] = polar(cx, cy, (ri + ro) / 2, mid);
      return { z, a0, a1, st, lx, ly };
    });
  };

  const segments = [...buildArc(upper, 200, 340), ...buildArc(lower, 20, 160)];

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 220 220"
      style={{ display: 'block', ...style }}
      role="img"
      aria-label="Mouth map"
    >
      {/* tongue/center hint */}
      <circle cx={cx} cy={cy} r={ri - 8} fill="var(--surface-mint)" />
      {segments.map(({ z, a0, a1, st, lx, ly }) => (
        <g key={z}>
          <path
            d={sectorPath(cx, cy, ri, ro, a0, a1)}
            fill={STATE_FILL[st]}
            stroke="var(--surface-card)"
            strokeWidth="2.5"
            style={{ transition: 'fill var(--dur-base) var(--ease-out)' }}
          />
          {st === 'done' && (
            <text x={lx} y={ly + 4} textAnchor="middle" fontSize="13" fontWeight="900" fill="#fff" fontFamily="var(--font-display)">
              ✓
            </text>
          )}
          {st === 'missed' && (
            <text x={lx} y={ly + 4} textAnchor="middle" fontSize="14" fontWeight="900" fill="#fff" fontFamily="var(--font-display)">
              !
            </text>
          )}
          {showLabels && (
            <text x={lx} y={ly + 14} textAnchor="middle" fontSize="6" fill="var(--text-tertiary)">
              {z}
            </text>
          )}
        </g>
      ))}
    </svg>
  );
}

import React from 'react';

/**
 * The 2-minute brushing countdown ring with Space Grotesk numerals.
 * Presentational — drive `remaining` from the session state machine.
 *
 * @startingPoint section="Brushing" subtitle="2-minute countdown ring" viewport="700x340"
 */
export interface BrushTimerProps {
  /** Seconds left in the session. */
  remaining?: number;
  /** Total session length (default 120 = 2 minutes). */
  total?: number;
  /** Sub-label under the time, e.g. "Brush your top teeth". */
  label?: string;
  size?: number;
  style?: React.CSSProperties;
}

export function BrushTimer(props: BrushTimerProps): JSX.Element;

The post-session AI coaching message, delivered by Sparky the mascot (self-contained — no asset needed). Keep copy warm, ~2 sentences, never clinical.

```jsx
<CoachCard score={88} message="Great brushing today! Tomorrow, try to reach all the way to your back teeth." />
```

Optional `score` shows a mint 0–100 chip next to the "Sparky says" title.

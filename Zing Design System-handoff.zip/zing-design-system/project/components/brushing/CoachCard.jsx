import React from 'react';

/** Compact inline Sparky mascot so CoachCard is self-contained. */
function SparkyMini({ size = 56 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-hidden="true">
      <path
        d="M50 14C28 14 15 27 15 48c0 16 5 30 11 41 3 6 11 5 14-1l5-17c1-3 6-3 7 0l5 17c3 6 11 7 14 1 6-11 11-25 11-41 0-21-13-34-35-34Z"
        fill="#fff" stroke="var(--mint-200)" strokeWidth="2.5"
      />
      <circle cx="38" cy="50" r="5.5" fill="var(--ink-900)" />
      <circle cx="62" cy="50" r="5.5" fill="var(--ink-900)" />
      <circle cx="32" cy="62" r="6" fill="var(--coral-500)" opacity="0.5" />
      <circle cx="68" cy="62" r="6" fill="var(--coral-500)" opacity="0.5" />
      <path d="M40 63c4 5 16 5 20 0" stroke="var(--ink-900)" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M78 24l3 8 8 3-8 3-3 8-3-8-8-3 8-3 3-8Z" fill="var(--sunny-500)" />
    </svg>
  );
}

/**
 * CoachCard — the post-session AI coaching message from Sparky. Warm, playful,
 * never clinical (CLAUDE.md > Gemini Coach). Optional score chip.
 */
export function CoachCard({ message, score = null, title = 'Sparky says', style = {} }) {
  return (
    <div
      style={{
        display: 'flex',
        gap: 14,
        padding: 18,
        borderRadius: 'var(--radius-2xl)',
        background: 'var(--surface-mint)',
        boxShadow: 'var(--shadow-card)',
        alignItems: 'flex-start',
        ...style,
      }}
    >
      <div style={{ flexShrink: 0 }}>
        <SparkyMini size={56} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: 'var(--mint-700)' }}>
            {title}
          </span>
          {score != null && (
            <span
              style={{
                fontFamily: 'var(--font-numeric)',
                fontWeight: 700,
                fontSize: 13,
                color: '#fff',
                background: 'var(--brand-primary)',
                borderRadius: 'var(--radius-pill)',
                padding: '2px 10px',
              }}
            >
              {score}/100
            </span>
          )}
        </div>
        <p
          style={{
            margin: 0,
            fontFamily: 'var(--font-body)',
            fontWeight: 600,
            fontSize: 17,
            lineHeight: 1.4,
            color: 'var(--text-primary)',
            textWrap: 'pretty',
          }}
        >
          {message}
        </p>
      </div>
    </div>
  );
}

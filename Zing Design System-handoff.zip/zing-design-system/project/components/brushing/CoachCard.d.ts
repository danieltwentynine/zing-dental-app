import React from 'react';

/**
 * Post-session AI coaching message delivered by Sparky the mascot. Keep copy
 * warm, encouraging and short; never clinical, never scolding.
 *
 * @startingPoint section="Brushing" subtitle="Sparky AI coach message" viewport="700x340"
 */
export interface CoachCardProps {
  /** The coaching message — warm, max ~2 sentences, never clinical. */
  message: string;
  /** Optional overall score 0–100. */
  score?: number | null;
  title?: string;
  style?: React.CSSProperties;
}

export function CoachCard(props: CoachCardProps): JSX.Element;

The signature Zing component — a stylized 10-zone dental arch (occlusal view) that fills as the child brushes, recreating the live camera overlay.

```jsx
<MouthMap states={{
  'top-front': 'done', 'top-left': 'done', 'top-right': 'active',
  'bottom-front': 'done', 'bottom-back-left': 'missed',
}} size={240} />
```

Zone states: `empty` (grey) → `active` (light mint) → `done` (solid mint + ✓). At session end, un-brushed zones show `missed` in warm orange — never red. `ALL_ZONES` lists the 10 keys (matching the app's `ToothZone` type). Zones transition smoothly with no flicker.

A child's colorful identity. `Avatar` renders one circle (a Phosphor icon on a brand color); `AvatarPicker` is the onboarding grid where the child taps to choose. Needs Phosphor Icons on the page.

```jsx
<Avatar avatarId="shark" size={48} />
<AvatarPicker value={avatar} onChange={setAvatar} />
```

`AVATAR_IDS` lists the available characters (shark, robot, rocket, cat, dog, butterfly, star, heart). Selected avatar gets a mint ring + pop.

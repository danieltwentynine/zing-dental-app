import React from 'react';

/**
 * StreakDisplay — the gold flame + day count that drives the daily habit.
 * Sizes: chip (inline), card (hero on the dashboard).
 */
export function StreakDisplay({ days = 0, best = null, layout = 'card', style = {} }) {
  const flame = (
    <svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 2c.6 3.2-1.7 4.6-3 6-1.4 1.5-2.5 3.2-2.5 5.5A5.5 5.5 0 0 0 12 19a5.5 5.5 0 0 0 5.5-5.5c0-1.7-.7-3-1.6-4.2-.5 1-1.3 1.6-2.2 1.7.9-2.4.2-5.6-1.7-9Z"
        fill="var(--feedback-reward)"
      />
      <path d="M12 19a3 3 0 0 1-3-3c0-1.4 1-2.4 1.8-3.3.4 1 1.2 1.5 2.2 1.6-.5 1.4-.1 3.2 1 4.2A3 3 0 0 1 12 19Z" fill="#fff" opacity="0.55" />
    </svg>
  );

  if (layout === 'chip') {
    return (
      <span
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          height: 30,
          padding: '0 12px 0 10px',
          borderRadius: 'var(--radius-pill)',
          background: 'var(--sunny-100)',
          color: '#9a7b12',
          fontFamily: 'var(--font-numeric)',
          fontWeight: 700,
          fontSize: 15,
          ...style,
        }}
      >
        <span style={{ fontSize: 18, display: 'inline-flex' }}>{flame}</span>
        {days}
      </span>
    );
  }

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        padding: 18,
        borderRadius: 'var(--radius-xl)',
        background: 'linear-gradient(135deg, #FFF7E0, #FFEFC2)',
        boxShadow: 'var(--shadow-card)',
        ...style,
      }}
    >
      <div
        style={{
          width: 56,
          height: 56,
          borderRadius: 'var(--radius-pill)',
          background: '#fff',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 30,
          boxShadow: 'var(--shadow-sunny)',
        }}
      >
        {flame}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
        <span style={{ fontFamily: 'var(--font-numeric)', fontWeight: 700, fontSize: 32, color: '#8a6d10' }}>
          {days} {days === 1 ? 'day' : 'days'}
        </span>
        <span style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, color: '#a9842a' }}>
          {days > 0 ? 'brushing streak' : 'Start your streak today!'}
          {best != null && days > 0 ? `  ·  best ${best}` : ''}
        </span>
      </div>
    </div>
  );
}

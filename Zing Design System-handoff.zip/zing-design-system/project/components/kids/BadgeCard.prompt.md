An achievement reward tile for the kids' progress screen. Earned tiles are full-color with a glow; locked tiles are dashed, dimmed and show a lock.

```jsx
<BadgeCard type="firstSession" earned caption="Day 1" />
<BadgeCard type="streak" name="7-Day Streak" earned />
<BadgeCard type="weeklyGoal" earned={false} />
```

Types map to the data model's `Badge.type`: `streak` `perfect` `firstSession` `weeklyGoal`. Needs Phosphor Icons on the page.

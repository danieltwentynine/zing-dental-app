Gold-flame streak counter — the core habit driver. `card` for the dashboard hero, `chip` for inline.

```jsx
<StreakDisplay days={7} best={12} />
<StreakDisplay days={3} layout="chip" />
```

Shows an encouraging "Start your streak today!" at 0 days.

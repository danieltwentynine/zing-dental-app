import React from 'react';

export interface StreakDisplayProps {
  days?: number;
  /** Best-ever streak, shown after the label in card layout. */
  best?: number | null;
  layout?: 'card' | 'chip';
  style?: React.CSSProperties;
}

/** Gold-flame streak counter that drives the daily-brushing habit. */
export function StreakDisplay(props: StreakDisplayProps): JSX.Element;

import React from 'react';

export interface BadgeCardProps {
  /** Maps to Badge.type in the data model. */
  type?: 'streak' | 'perfect' | 'firstSession' | 'weeklyGoal';
  /** Custom name; defaults to a per-type label. */
  name?: string;
  earned?: boolean;
  caption?: string;
  style?: React.CSSProperties;
}

/**
 * A kid's achievement reward tile. Earned = full color + glow; locked = dashed
 * + dimmed with a lock. Requires Phosphor Icons loaded on the page.
 */
export function BadgeCard(props: BadgeCardProps): JSX.Element;

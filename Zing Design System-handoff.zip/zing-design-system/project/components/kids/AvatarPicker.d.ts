import React from 'react';

export const AVATAR_IDS: string[];

export interface AvatarProps {
  avatarId?: string;
  size?: number;
  /** Mint selection ring. */
  ring?: boolean;
  style?: React.CSSProperties;
}

/**
 * Grid of tappable avatars for the child to pick during onboarding.
 *
 * @startingPoint section="Kids" subtitle="Child avatar picker grid" viewport="700x340"
 */
export interface AvatarPickerProps {
  value?: string;
  onChange?: (avatarId: string) => void;
  style?: React.CSSProperties;
}

/** A child's colorful identity circle (icon on a color). */
export function Avatar(props: AvatarProps): JSX.Element;

export function AvatarPicker(props: AvatarPickerProps): JSX.Element;

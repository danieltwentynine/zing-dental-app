import React from 'react';

/**
 * BadgeCard — a kid's achievement reward. Earned = full color + glow;
 * locked = greyed and dimmed. Maps to Badge.type in the data model.
 */
const BADGE_META = {
  streak: { icon: 'ph-fill ph-fire', color: 'var(--sunny-500)', wash: 'var(--sunny-100)', label: 'On Fire' },
  perfect: { icon: 'ph-fill ph-star', color: 'var(--mint-500)', wash: 'var(--mint-100)', label: 'Perfect Brush' },
  firstSession: { icon: 'ph-fill ph-tooth', color: 'var(--sky-400)', wash: 'var(--sky-100)', label: 'First Brush' },
  weeklyGoal: { icon: 'ph-fill ph-trophy', color: 'var(--grape-500)', wash: 'var(--grape-100)', label: 'Weekly Star' },
};

export function BadgeCard({ type = 'firstSession', name, earned = true, caption = '', style = {} }) {
  const meta = BADGE_META[type] || BADGE_META.firstSession;
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 10,
        width: 116,
        padding: '18px 12px',
        borderRadius: 'var(--radius-xl)',
        background: 'var(--surface-card)',
        boxShadow: earned ? 'var(--shadow-card)' : 'none',
        border: earned ? 'none' : '1.5px dashed var(--border-strong)',
        opacity: earned ? 1 : 0.6,
        textAlign: 'center',
        ...style,
      }}
    >
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: 'var(--radius-pill)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 34,
          color: earned ? '#fff' : 'var(--ink-400)',
          background: earned ? meta.color : 'var(--ink-100)',
          boxShadow: earned ? 'var(--shadow-sm)' : 'none',
        }}
      >
        <i className={earned ? meta.icon : 'ph-bold ph-lock-simple'} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14, color: 'var(--text-primary)' }}>
          {name || meta.label}
        </span>
        {caption && (
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--text-secondary)' }}>{caption}</span>
        )}
      </div>
    </div>
  );
}

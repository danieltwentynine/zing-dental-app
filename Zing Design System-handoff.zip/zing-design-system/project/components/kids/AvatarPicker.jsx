import React from 'react';

/**
 * Avatar — a single child's colorful identity circle (an icon on a color).
 * Used standalone (in headers, session screens) and inside AvatarPicker.
 */
const AVATARS = {
  shark: { icon: 'ph-fill ph-shark', bg: 'var(--sky-400)' },
  robot: { icon: 'ph-fill ph-robot', bg: 'var(--grape-500)' },
  rocket: { icon: 'ph-fill ph-rocket', bg: 'var(--coral-500)' },
  cat: { icon: 'ph-fill ph-cat', bg: 'var(--sunny-500)' },
  dog: { icon: 'ph-fill ph-dog', bg: 'var(--mint-500)' },
  butterfly: { icon: 'ph-fill ph-butterfly', bg: 'var(--sky-500)' },
  star: { icon: 'ph-fill ph-star', bg: 'var(--warning-500)' },
  heart: { icon: 'ph-fill ph-heart', bg: 'var(--coral-500)' },
};

export const AVATAR_IDS = Object.keys(AVATARS);

export function Avatar({ avatarId = 'dog', size = 56, ring = false, style = {} }) {
  const a = AVATARS[avatarId] || AVATARS.dog;
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 'var(--radius-pill)',
        background: a.bg,
        color: '#fff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: size * 0.52,
        boxShadow: ring ? '0 0 0 3px var(--surface-card), 0 0 0 6px ' + a.bg : 'var(--shadow-sm)',
        flexShrink: 0,
        ...style,
      }}
    >
      <i className={a.icon} />
    </div>
  );
}

/**
 * AvatarPicker — the child chooses their character during onboarding.
 * A friendly grid of big, tappable avatars; selected one gets a mint ring.
 */
export function AvatarPicker({ value = 'dog', onChange, style = {} }) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 14,
        ...style,
      }}
    >
      {AVATAR_IDS.map((id) => {
        const selected = id === value;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange && onChange(id)}
            aria-pressed={selected}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 6,
              borderRadius: 'var(--radius-pill)',
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              transform: selected ? 'scale(1.06)' : 'scale(1)',
              transition: 'transform var(--dur-base) var(--ease-bounce)',
              WebkitTapHighlightColor: 'transparent',
            }}
          >
            <Avatar avatarId={id} size={62} ring={selected} />
          </button>
        );
      })}
    </div>
  );
}

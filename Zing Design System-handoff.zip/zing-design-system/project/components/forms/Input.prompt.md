Labelled text field matching the app's register screen — 56px tall, 16px radius, border turns mint on focus and danger-red on error.

```jsx
<Input label="Your name" value={name} onChange={setName} placeholder="e.g. Maria" />
<Input label="Email" type="email" value={email} onChange={setEmail}
       error="That email address doesn't look right" />
```

Use human labels and helpful, friendly error copy (never error codes). Supports a leading `icon`.

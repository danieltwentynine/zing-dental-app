import React from 'react';

/**
 * Zing Input — mirrors the app's register-screen field: 56px tall, 16px radius,
 * 1.5px subtle border that turns mint on focus / danger on error.
 * Label + optional error message in the brand voice.
 */
export function Input({
  label,
  value,
  onChange,
  placeholder = '',
  type = 'text',
  error = '',
  icon = null,
  disabled = false,
  style = {},
  inputStyle = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const borderColor = error
    ? 'var(--feedback-danger)'
    : focused
    ? 'var(--border-focus)'
    : 'var(--border-subtle)';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && (
        <label
          style={{
            fontFamily: 'var(--font-body)',
            fontWeight: 600,
            fontSize: 14,
            color: 'var(--text-primary)',
          }}
        >
          {label}
        </label>
      )}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          height: 56,
          padding: '0 16px',
          borderRadius: 'var(--radius-lg)',
          background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
          border: `1.5px solid ${borderColor}`,
          boxShadow: focused && !error ? '0 0 0 4px rgba(0,201,167,0.12)' : 'none',
          transition: 'border-color var(--dur-base), box-shadow var(--dur-base)',
        }}
      >
        {icon && <span style={{ color: 'var(--text-tertiary)', display: 'inline-flex', fontSize: 20 }}>{icon}</span>}
        <input
          value={value}
          onChange={(e) => onChange && onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          type={type}
          disabled={disabled}
          style={{
            flex: 1,
            border: 'none',
            outline: 'none',
            background: 'transparent',
            fontFamily: 'var(--font-body)',
            fontWeight: 400,
            fontSize: 16,
            color: 'var(--text-primary)',
            minWidth: 0,
            ...inputStyle,
          }}
          {...rest}
        />
      </div>
      {error && (
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--feedback-danger)' }}>
          {error}
        </span>
      )}
    </div>
  );
}

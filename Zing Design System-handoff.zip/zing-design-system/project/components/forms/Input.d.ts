import React from 'react';

/**
 * Labelled text field — 56px, 16px radius, border turns mint on focus and
 * danger on error. Use human labels ("Your name") and helpful error copy.
 *
 * @startingPoint section="Forms" subtitle="Labelled text field with focus + error" viewport="700x330"
 */
export interface InputProps {
  label?: string;
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  type?: string;
  /** Error message in brand voice — turns the border danger-red. */
  error?: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  style?: React.CSSProperties;
  inputStyle?: React.CSSProperties;
}

export function Input(props: InputProps): JSX.Element;

/* global React, ZingDesignSystem_f62470 */
// Welcome + Register + Child setup screens.
(function () {
const ZDS_auth = window.ZingDesignSystem_f62470;
const { useState } = React;

function WelcomeScreen({ onStart, onLogin }) {
  const { Button } = ZDS_auth;
  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column',
      background: 'linear-gradient(180deg, var(--surface-mint) 0%, var(--surface-page) 70%)',
      padding: '8px 28px 32px', textAlign: 'center' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
        <img src="../../assets/zing-mascot.svg" alt="Sparky" style={{ width: 168, marginBottom: 8 }} />
        <img src="../../assets/zing-wordmark.svg" alt="Zing" style={{ height: 56 }} />
        <p style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 18, lineHeight: 1.45,
          color: 'var(--text-secondary)', margin: '10px 0 0', maxWidth: 280, textWrap: 'pretty' }}>
          The brushing buddy that turns two minutes into a daily adventure.
        </p>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Button label="Get started" fullWidth size="lg" onClick={onStart} />
        <Button label="I already have an account" variant="ghost" fullWidth onClick={onLogin} />
      </div>
    </div>
  );
}

function RegisterScreen({ onSubmit, onBack }) {
  const { Button, Input } = ZDS_auth;
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const emailErr = email.length > 0 && !email.includes('@') ? "That email address doesn't look right" : '';

  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', padding: '4px 24px 28px' }}>
      <button onClick={onBack} style={{ alignSelf: 'flex-start', background: 'none', border: 'none',
        cursor: 'pointer', color: 'var(--text-secondary)', fontSize: 26, marginBottom: 6, padding: 4 }}>
        <i className="ph-bold ph-arrow-left" />
      </button>
      <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 30, color: 'var(--text-primary)',
        margin: '4px 0 6px' }}>Welcome to Zing</h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: 16, color: 'var(--text-secondary)', margin: '0 0 22px', lineHeight: 1.45 }}>
        Create your parent account to start your child's brushing adventure.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, flex: 1 }}>
        <Input label="Your name" value={name} onChange={setName} placeholder="e.g. Maria" icon={<i className="ph-bold ph-user" />} />
        <Input label="Email" value={email} onChange={setEmail} placeholder="you@example.com" error={emailErr} icon={<i className="ph-bold ph-envelope-simple" />} />
        <Input label="Password" type="password" value={pw} onChange={setPw} placeholder="At least 8 characters" icon={<i className="ph-bold ph-lock-simple" />} />
      </div>
      <Button label="Create account" fullWidth size="lg" style={{ marginTop: 20 }} onClick={onSubmit} />
      <p style={{ textAlign: 'center', fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-secondary)', marginTop: 16 }}>
        Already have an account? <span style={{ color: 'var(--text-link)', fontWeight: 700 }}>Log in</span>
      </p>
    </div>
  );
}

function ChildSetupScreen({ onDone }) {
  const { Button, Input, Chip, AvatarPicker } = ZDS_auth;
  const [name, setName] = useState('Leo');
  const [age, setAge] = useState(6);
  const [avatar, setAvatar] = useState('shark');

  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', padding: '4px 24px 28px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <span style={{ fontFamily: 'var(--font-numeric)', fontWeight: 700, fontSize: 12, color: 'var(--brand-primary)',
          background: 'var(--surface-mint)', padding: '4px 10px', borderRadius: 999 }}>STEP 2 OF 2</span>
      </div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 28, color: 'var(--text-primary)', margin: '4px 0 4px' }}>
        Add your child
      </h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: 15, color: 'var(--text-secondary)', margin: '0 0 20px' }}>
        You can add more children later.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18, flex: 1 }}>
        <Input label="Child's name" value={name} onChange={setName} placeholder="e.g. Leo" />
        <div>
          <div style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, color: 'var(--text-primary)', marginBottom: 8 }}>Age</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[4, 5, 6, 7, 8, 9].map((a) => <Chip key={a} label={String(a)} selected={age === a} onClick={() => setAge(a)} />)}
          </div>
        </div>
        <div>
          <div style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 14, color: 'var(--text-primary)', marginBottom: 10 }}>Pick a character</div>
          <AvatarPicker value={avatar} onChange={setAvatar} />
        </div>
      </div>
      <Button label="Start brushing adventure" fullWidth size="lg" style={{ marginTop: 22 }}
        onClick={() => onDone({ name, age, avatar })} />
    </div>
  );
}

window.ZingAuth = { WelcomeScreen, RegisterScreen, ChildSetupScreen };
})();

# Zing — App UI Kit

A high-fidelity, interactive recreation of the Zing mobile app (iOS-first, React Native + Expo + NativeWind in production). Open **`index.html`** for the click-through.

## Flow
`Welcome → Register → Add child (avatar picker) → Home dashboard → [tap Brush] → 3·2·1 countdown → live brushing session (Mouth Map + 2-min timer) → Results (score + Sparky coach message) → Progress (streak, badges, history)`

The bottom tab bar's center button launches a brushing session from anywhere; the session is compressed to ~30s for demoing and intentionally leaves the back teeth un-brushed so the "missed zones" + coaching message can be shown.

## Files
- `index.html` — entry point + navigation root (the app state machine).
- `AppShell.jsx` — iPhone frame, status bar, bottom tab bar, screen router.
- `AuthScreens.jsx` — Welcome, Register, Child setup.
- `Dashboard.jsx` — Home dashboard, Progress.
- `Session.jsx` — Brushing session (countdown + live) and Results.

## Provenance & fidelity
Built from `danieltwentynine/zing-dental-app-`. In production the app is at **Phase 1** — only the parent **Register** screen is fully implemented, and it is reproduced here faithfully (copy, field pattern, validation voice). Every other screen is a **forward recreation** built strictly from the specs in the repo's `CLAUDE.md` (the design system, the Mouth Map spec, the brushing state machine, the Gemini coach tone) — they are not 1:1 copies of shipped code, because that code does not exist yet. Treat them as the intended design, ready to validate against the team.

All screens compose the design-system primitives (`Button`, `Input`, `Card`, `Chip`, `Avatar`, `AvatarPicker`, `StreakDisplay`, `BadgeCard`, `MouthMap`, `BrushTimer`, `CoachCard`) — nothing is re-implemented locally.

/* global React, ZingDesignSystem_f62470 */
// Brushing session (countdown → live) + Results.
(function () {
const ZDS_sess = window.ZingDesignSystem_f62470;
const { useState, useEffect, useRef } = React;

const BRUSH_ORDER = [
  'top-front', 'top-left', 'top-right', 'bottom-front', 'bottom-left',
  'bottom-right', 'top-back-right', 'top-back-left',
]; // leaves bottom-back-left / bottom-back-right un-brushed → "back teeth" coaching
const ZONE_HINTS = {
  'top-front': 'Brush your top front teeth',
  'top-left': 'Now the top left',
  'top-right': 'Now the top right',
  'bottom-front': 'Down to the bottom front',
  'bottom-left': 'Bottom left now',
  'bottom-right': 'Bottom right — nice!',
  'top-back-right': "Reach the back, you've got this",
  'top-back-left': 'Last few — keep going!',
};

function Countdown({ n }) {
  return (
    <div key={n} style={{ fontFamily: 'var(--font-numeric)', fontWeight: 700, fontSize: 160, color: '#fff',
      lineHeight: 1, animation: 'zing-pop 0.6s var(--ease-bounce)' }}>{n}</div>
  );
}

function BrushSession({ child, onComplete, onCancel }) {
  const { MouthMap, BrushTimer } = ZDS_sess;
  const [phase, setPhase] = useState('countdown'); // countdown | active
  const [count, setCount] = useState(3);
  const [remaining, setRemaining] = useState(120);
  const [states, setStates] = useState({});
  const stepRef = useRef(0);

  // Countdown 3-2-1
  useEffect(() => {
    if (phase !== 'countdown') return;
    if (count === 0) { setPhase('active'); return; }
    const t = setTimeout(() => setCount((c) => c - 1), 800);
    return () => clearTimeout(t);
  }, [phase, count]);

  // Active session — compressed to ~30s for the demo
  useEffect(() => {
    if (phase !== 'active') return;
    const total = 120;
    const tickMs = 250;
    const dec = 1;
    const interval = setInterval(() => {
      setRemaining((r) => {
        const next = r - dec;
        // advance brushing progress proportionally
        const elapsed = total - next;
        const idx = Math.floor((elapsed / total) * BRUSH_ORDER.length);
        if (idx !== stepRef.current) {
          stepRef.current = idx;
          setStates((prev) => {
            const ns = { ...prev };
            for (let i = 0; i < idx; i++) ns[BRUSH_ORDER[i]] = 'done';
            if (idx < BRUSH_ORDER.length) ns[BRUSH_ORDER[idx]] = 'active';
            return ns;
          });
        }
        if (next <= 0) {
          clearInterval(interval);
          finish();
          return 0;
        }
        return next;
      });
    }, tickMs);
    return () => clearInterval(interval);
    // eslint-disable-next-line
  }, [phase]);

  function finish() {
    const final = {};
    ALL_ZONES_LOCAL.forEach((z) => { final[z] = 'empty'; });
    BRUSH_ORDER.forEach((z) => { final[z] = 'done'; });
    final['bottom-back-left'] = 'missed';
    final['bottom-back-right'] = 'missed';
    const done = BRUSH_ORDER.length;
    const score = Math.round((done / 10) * 100); // 80
    setTimeout(() => onComplete({ states: final, score, missed: ['bottom-back-left', 'bottom-back-right'] }), 350);
  }

  const ALL_ZONES_LOCAL = ZDS_sess.ALL_ZONES;
  const currentZone = BRUSH_ORDER[Math.min(stepRef.current, BRUSH_ORDER.length - 1)];

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 90% at 50% 0%, #0b3b3a 0%, #07282c 60%, #051c20 100%)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', color: '#fff' }}>
      {/* cancel */}
      <button onClick={onCancel} style={{ position: 'absolute', top: 16, right: 20, zIndex: 5, background: 'rgba(255,255,255,0.14)',
        border: 'none', borderRadius: 999, width: 40, height: 40, color: '#fff', fontSize: 20, cursor: 'pointer' }}>
        <i className="ph-bold ph-x" />
      </button>

      {phase === 'countdown' ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
          <Countdown n={count === 0 ? 'Go!' : count} />
          <div style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 17, color: 'rgba(255,255,255,0.8)' }}>
            Get your toothbrush ready, {child.name}!
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%', padding: '20px 24px 28px' }}>
          {/* live camera chip */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: 'rgba(255,90,95,0.18)', color: '#ff8a8d',
            padding: '5px 12px', borderRadius: 999, fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 12, marginTop: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: 999, background: '#ff5a5f', display: 'inline-block' }} />
            CAMERA LIVE · on-device
          </div>

          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MouthMap states={states} size={260} />
          </div>

          {/* zone hint */}
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, textAlign: 'center', minHeight: 30 }}>
            {ZONE_HINTS[currentZone]}
          </div>

          <div style={{ margin: '18px 0 8px' }}>
            <BrushTimer remaining={remaining} total={120} size={150}
              style={{ filter: 'drop-shadow(0 6px 16px rgba(0,201,167,0.4))' }} />
          </div>

          <button onClick={finish} style={{ background: 'rgba(255,255,255,0.15)', border: 'none', color: '#fff',
            fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, padding: '12px 28px', borderRadius: 999, cursor: 'pointer' }}>
            I'm done
          </button>
        </div>
      )}
    </div>
  );
}

function ResultsScreen({ child, result, onAgain, onProgress }) {
  const { MouthMap, CoachCard, Button } = ZDS_sess;
  const msg = `Awesome job, ${child.name}! Tomorrow, try to reach all the way to your back teeth.`;
  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', padding: '8px 24px 28px', alignItems: 'center', textAlign: 'center' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14, letterSpacing: '0.08em',
        color: 'var(--brand-primary)', marginTop: 6 }}>SESSION COMPLETE</div>
      <div style={{ fontFamily: 'var(--font-numeric)', fontWeight: 700, fontSize: 88, color: 'var(--text-primary)', lineHeight: 1, margin: '4px 0' }}>
        {result.score}<span style={{ fontSize: 34, color: 'var(--text-tertiary)' }}>/100</span>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, color: 'var(--text-primary)' }}>Great brushing!</div>

      <div style={{ margin: '14px 0 6px' }}>
        <MouthMap states={result.states} size={200} />
      </div>
      <div style={{ display: 'flex', gap: 16, marginBottom: 18, fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 12 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--text-secondary)' }}>
          <span style={{ width: 11, height: 11, borderRadius: 3, background: 'var(--zone-done)' }} /> Brushed</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--text-secondary)' }}>
          <span style={{ width: 11, height: 11, borderRadius: 3, background: 'var(--zone-missed)' }} /> Missed</span>
      </div>

      <CoachCard score={result.score} message={msg} style={{ width: '100%', textAlign: 'left' }} />

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', marginTop: 'auto', paddingTop: 22 }}>
        <Button label="See my progress" fullWidth size="lg" onClick={onProgress} />
        <Button label="Brush again" variant="soft" fullWidth onClick={onAgain} />
      </div>
    </div>
  );
}

window.ZingSession = { BrushSession, ResultsScreen };
})();

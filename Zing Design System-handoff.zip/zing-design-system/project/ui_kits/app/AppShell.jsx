/* global React */
// Zing app shell — iPhone frame, status bar, bottom tab bar, screen router.
(function () {
const { useState, useEffect, useRef } = React;

function StatusBar({ dark = false }) {
  const color = dark ? '#fff' : 'var(--text-primary)';
  return (
    <div style={{ height: 50, display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      padding: '0 28px 8px', flexShrink: 0 }}>
      <span style={{ fontFamily: 'var(--font-numeric)', fontWeight: 700, fontSize: 15, color }}>9:41</span>
      <div style={{ display: 'flex', gap: 7, alignItems: 'center', color }}>
        <i className="ph-fill ph-cell-signal-full" style={{ fontSize: 16 }} />
        <i className="ph-fill ph-wifi-high" style={{ fontSize: 16 }} />
        <i className="ph-fill ph-battery-full" style={{ fontSize: 18 }} />
      </div>
    </div>
  );
}

function TabBar({ tab, onTab }) {
  const items = [
    { id: 'home', icon: 'house', label: 'Home' },
    { id: 'progress', icon: 'chart-line-up', label: 'Progress' },
  ];
  return (
    <div style={{ position: 'relative', height: 88, flexShrink: 0, background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'flex-start',
      paddingTop: 12, boxShadow: '0 -6px 20px rgba(15,32,39,0.04)' }}>
      <TabButton {...items[0]} active={tab === 'home'} onClick={() => onTab('home')} />
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
        <button onClick={() => onTab('brush')} aria-label="Start brushing" style={{
          position: 'absolute', top: -26, width: 66, height: 66, borderRadius: '50%',
          background: 'var(--brand-primary)', border: '4px solid var(--surface-card)', cursor: 'pointer',
          boxShadow: 'var(--shadow-mint)', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 30 }}>
          <i className="ph-fill ph-tooth" />
        </button>
        <span style={{ position: 'absolute', top: 46, fontFamily: 'var(--font-body)', fontWeight: 700,
          fontSize: 11, color: 'var(--brand-primary)' }}>Brush</span>
      </div>
      <TabButton {...items[1]} active={tab === 'progress'} onClick={() => onTab('progress')} />
    </div>
  );
}

function TabButton({ icon, label, active, onClick }) {
  const color = active ? 'var(--brand-primary)' : 'var(--text-tertiary)';
  return (
    <button onClick={onClick} style={{ flex: 1, background: 'none', border: 'none', cursor: 'pointer',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, color }}>
      <i className={`${active ? 'ph-fill' : 'ph-bold'} ph-${icon}`} style={{ fontSize: 25 }} />
      <span style={{ fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 11 }}>{label}</span>
    </button>
  );
}

// The phone shell. `chrome` = 'tabs' shows the tab bar; 'none' is full-bleed (session).
function Phone({ children, chrome = 'tabs', tab, onTab, statusDark = false, bg = 'var(--surface-page)' }) {
  return (
    <div style={{
      width: 402, height: 858, borderRadius: 56, background: '#0f2027', padding: 11,
      boxShadow: '0 40px 90px -30px rgba(15,32,39,0.5)', flexShrink: 0, position: 'relative' }}>
      <div style={{ width: '100%', height: '100%', borderRadius: 46, overflow: 'hidden',
        background: bg, display: 'flex', flexDirection: 'column', position: 'relative' }}>
        {/* notch */}
        <div style={{ position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
          width: 120, height: 30, background: '#0f2027', borderRadius: 18, zIndex: 20 }} />
        <StatusBar dark={statusDark} />
        <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', position: 'relative' }}>
          {children}
        </div>
        {chrome === 'tabs' && <TabBar tab={tab} onTab={onTab} />}
      </div>
    </div>
  );
}

window.ZingShell = { Phone, StatusBar, TabBar };
})();

/* global React, ZingDesignSystem_f62470 */
// Home dashboard + Progress screens.
(function () {
const ZDS_dash = window.ZingDesignSystem_f62470;

function SectionTitle({ children, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', margin: '0 0 12px' }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 19, color: 'var(--text-primary)', margin: 0 }}>{children}</h2>
      {action}
    </div>
  );
}

function HomeScreen({ child, streak, onBrush }) {
  const { Card, Avatar, StreakDisplay, Badge } = ZDS_dash;
  const slots = [
    { label: 'Morning', icon: 'sun', done: true, time: '7:52 AM' },
    { label: 'Evening', icon: 'moon', done: false, time: 'Not yet' },
  ];
  return (
    <div style={{ padding: '4px 20px 28px', display: 'flex', flexDirection: 'column', gap: 22 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-secondary)', fontWeight: 600 }}>Good morning,</div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, color: 'var(--text-primary)' }}>Maria</div>
        </div>
        <div style={{ width: 44, height: 44, borderRadius: 999, background: 'var(--surface-card)', boxShadow: 'var(--shadow-sm)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-secondary)', fontSize: 22 }}>
          <i className="ph-bold ph-gear" />
        </div>
      </div>

      {/* Active child card */}
      <Card tone="mint" padding={18} radius="var(--radius-2xl)">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Avatar avatarId={child.avatar} size={62} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: 'var(--text-primary)' }}>{child.name}</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--text-secondary)', fontWeight: 600 }}>Age {child.age}</div>
          </div>
          <StreakDisplay days={streak} layout="chip" />
        </div>
      </Card>

      {/* Today's brushing */}
      <div>
        <SectionTitle>Today's brushing</SectionTitle>
        <div style={{ display: 'flex', gap: 12 }}>
          {slots.map((s) => (
            <Card key={s.label} padding={16} style={{ flex: 1, textAlign: 'center' }}>
              <div style={{ width: 44, height: 44, margin: '0 auto 8px', borderRadius: 999,
                background: s.done ? 'var(--surface-mint)' : 'var(--surface-sunken)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22,
                color: s.done ? 'var(--brand-primary)' : 'var(--text-tertiary)' }}>
                <i className={`ph-fill ph-${s.done ? 'check-circle' : s.icon}`} />
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: 'var(--text-primary)' }}>{s.label}</div>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600,
                color: s.done ? 'var(--mint-600)' : 'var(--text-tertiary)' }}>{s.done ? `Done · ${s.time}` : s.time}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* CTA */}
      <Card padding={20} radius="var(--radius-2xl)" style={{ background: 'linear-gradient(135deg, #00D7B2, #00A98C)', boxShadow: 'var(--shadow-mint)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: '#fff' }}>Time to brush!</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'rgba(255,255,255,0.9)', fontWeight: 600, marginTop: 2 }}>
              Sparky is ready for your evening session.
            </div>
          </div>
          <button onClick={onBrush} style={{ width: 56, height: 56, borderRadius: 999, border: 'none', cursor: 'pointer',
            background: '#fff', color: 'var(--brand-primary)', fontSize: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 6px 16px rgba(0,0,0,0.15)' }}>
            <i className="ph-fill ph-play" />
          </button>
        </div>
      </Card>
    </div>
  );
}

function ProgressScreen({ child, streak }) {
  const { Card, StreakDisplay, BadgeCard, Badge } = ZDS_dash;
  const week = [
    { d: 'M', done: true }, { d: 'T', done: true }, { d: 'W', done: true },
    { d: 'T', done: true }, { d: 'F', done: true }, { d: 'S', done: false }, { d: 'S', done: false },
  ];
  const history = [
    { day: 'Today · Morning', score: 88, tone: 'mint' },
    { day: 'Yesterday · Evening', score: 95, tone: 'mint' },
    { day: 'Yesterday · Morning', score: 72, tone: 'warning' },
  ];
  return (
    <div style={{ padding: '4px 20px 28px', display: 'flex', flexDirection: 'column', gap: 22 }}>
      <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, color: 'var(--text-primary)', margin: '4px 0 0' }}>
        {child.name}'s progress
      </h1>

      <StreakDisplay days={streak} best={12} />

      {/* This week */}
      <Card padding={18}>
        <SectionTitle>This week</SectionTitle>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          {week.map((w, i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, background: w.done ? 'var(--brand-primary)' : 'var(--surface-sunken)',
                color: w.done ? '#fff' : 'var(--text-tertiary)' }}>
                {w.done ? <i className="ph-bold ph-check" /> : null}
              </div>
              <span style={{ fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: 12, color: 'var(--text-tertiary)' }}>{w.d}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Badges */}
      <div>
        <SectionTitle>Badges</SectionTitle>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 4 }}>
          <BadgeCard type="firstSession" earned caption="Day 1" />
          <BadgeCard type="streak" name="7-Day Streak" earned />
          <BadgeCard type="perfect" earned caption="95/100" />
          <BadgeCard type="weeklyGoal" earned={false} />
        </div>
      </div>

      {/* History */}
      <div>
        <SectionTitle>Recent sessions</SectionTitle>
        <Card padding={6}>
          {history.map((h, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '12px 14px', borderBottom: i < history.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
              <span style={{ fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 15, color: 'var(--text-primary)' }}>{h.day}</span>
              <Badge tone={h.tone} solid={h.tone === 'mint'} label={`${h.score}/100`} />
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

window.ZingDashboard = { HomeScreen, ProgressScreen };
})();

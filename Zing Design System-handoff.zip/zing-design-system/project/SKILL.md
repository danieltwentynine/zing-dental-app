---
name: zing-design
description: Use this skill to generate well-branded interfaces and assets for Zing — an AI dental-coaching app for kids (ages 4–12) — for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, brand assets, and UI-kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

Zing is a playful, kid-friendly dental-coaching app: mint + sky palette, rounded Nunito type, pillowy cards, soft tinted shadows, springy motion, two voices (warm for kids, reassuring for parents), and a friendly tooth mascot named Sparky. Keep it simple, safe, and never clinical; no emoji in product copy.

Key files:
- `README.md` — the full design guide: product context, voice & tone, visual foundations, iconography, and an index of everything.
- `styles.css` + `tokens/` — the CSS custom properties (colors, type, spacing, radii, shadows, motion) and `@font-face` webfonts. Link `styles.css` to inherit the system.
- `assets/` — brand mark, app icon, wordmark, and the Sparky mascot (SVG).
- `components/` — reusable React primitives (Button, Input, Card, Chip, Badge, Avatar/AvatarPicker, StreakDisplay, BadgeCard, MouthMap, BrushTimer, CoachCard). Each has a `.prompt.md` with usage.
- `guidelines/` — foundation specimen cards (color, type, spacing, brand).
- `ui_kits/app/` — a full interactive recreation of the mobile app to reference for screen composition.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and create static HTML files for the user to view. If working on production code (React Native + Expo + NativeWind), read the rules here and reference the original repo `danieltwentynine/zing-dental-app-` to design with the brand accurately.

If the user invokes this skill without other guidance, ask what they want to build or design, ask a few clarifying questions, and act as an expert designer who outputs HTML artifacts **or** production code, depending on the need.

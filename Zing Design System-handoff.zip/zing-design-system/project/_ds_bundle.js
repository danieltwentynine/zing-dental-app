/* @ds-bundle: {"format":4,"namespace":"ZingDesignSystem_f62470","components":[{"name":"BrushTimer","sourcePath":"components/brushing/BrushTimer.jsx"},{"name":"CoachCard","sourcePath":"components/brushing/CoachCard.jsx"},{"name":"ALL_ZONES","sourcePath":"components/brushing/MouthMap.jsx"},{"name":"MouthMap","sourcePath":"components/brushing/MouthMap.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"AVATAR_IDS","sourcePath":"components/kids/AvatarPicker.jsx"},{"name":"Avatar","sourcePath":"components/kids/AvatarPicker.jsx"},{"name":"AvatarPicker","sourcePath":"components/kids/AvatarPicker.jsx"},{"name":"BadgeCard","sourcePath":"components/kids/BadgeCard.jsx"},{"name":"StreakDisplay","sourcePath":"components/kids/StreakDisplay.jsx"}],"sourceHashes":{"components/brushing/BrushTimer.jsx":"058a08ff50a4","components/brushing/CoachCard.jsx":"6eaa2c44de2f","components/brushing/MouthMap.jsx":"ee0b7c0efe8f","components/core/Badge.jsx":"d504fcdcaf78","components/core/Button.jsx":"ba79a1bec5e9","components/core/Card.jsx":"3a7545e2d682","components/core/Chip.jsx":"dbc06c884308","components/forms/Input.jsx":"458b33b1f9f2","components/kids/AvatarPicker.jsx":"d47d585a1ba6","components/kids/BadgeCard.jsx":"118839ee0a64","components/kids/StreakDisplay.jsx":"bd190184989a","guidelines/tweaks-panel.jsx":"6591467622ed","ui_kits/app/AppShell.jsx":"aff849d704fa","ui_kits/app/AuthScreens.jsx":"9f35038e4966","ui_kits/app/Dashboard.jsx":"2e6384adc944","ui_kits/app/Session.jsx":"f730a23f96a7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ZingDesignSystem_f62470 = window.ZingDesignSystem_f62470 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brushing/BrushTimer.jsx
try { (() => {
/**
 * BrushTimer — the 2-minute brushing countdown. A big mint progress ring with
 * Space Grotesk numerals in the center. Purely presentational: pass the
 * remaining seconds; drive it from the session state machine.
 */
function BrushTimer({
  remaining = 120,
  total = 120,
  label = '',
  size = 240,
  style = {}
}) {
  const r = size / 2 - 14;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, 1 - remaining / total));
  const mm = Math.floor(remaining / 60);
  const ss = String(Math.floor(remaining % 60)).padStart(2, '0');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size,
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    style: {
      transform: 'rotate(-90deg)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--ink-100)",
    strokeWidth: "14"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--brand-primary)",
    strokeWidth: "14",
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: c * (1 - pct),
    style: {
      transition: 'stroke-dashoffset 1s linear'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-numeric)',
      fontWeight: 700,
      fontSize: size * 0.26,
      color: 'var(--text-primary)',
      lineHeight: 1,
      letterSpacing: '-0.02em'
    }
  }, mm, ":", ss), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--text-secondary)'
    }
  }, label)));
}
Object.assign(__ds_scope, { BrushTimer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brushing/BrushTimer.jsx", error: String((e && e.message) || e) }); }

// components/brushing/CoachCard.jsx
try { (() => {
/** Compact inline Sparky mascot so CoachCard is self-contained. */
function SparkyMini({
  size = 56
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 100 100",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M50 14C28 14 15 27 15 48c0 16 5 30 11 41 3 6 11 5 14-1l5-17c1-3 6-3 7 0l5 17c3 6 11 7 14 1 6-11 11-25 11-41 0-21-13-34-35-34Z",
    fill: "#fff",
    stroke: "var(--mint-200)",
    strokeWidth: "2.5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "38",
    cy: "50",
    r: "5.5",
    fill: "var(--ink-900)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "62",
    cy: "50",
    r: "5.5",
    fill: "var(--ink-900)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "62",
    r: "6",
    fill: "var(--coral-500)",
    opacity: "0.5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "68",
    cy: "62",
    r: "6",
    fill: "var(--coral-500)",
    opacity: "0.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M40 63c4 5 16 5 20 0",
    stroke: "var(--ink-900)",
    strokeWidth: "3",
    strokeLinecap: "round",
    fill: "none"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M78 24l3 8 8 3-8 3-3 8-3-8-8-3 8-3 3-8Z",
    fill: "var(--sunny-500)"
  }));
}

/**
 * CoachCard — the post-session AI coaching message from Sparky. Warm, playful,
 * never clinical (CLAUDE.md > Gemini Coach). Optional score chip.
 */
function CoachCard({
  message,
  score = null,
  title = 'Sparky says',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      padding: 18,
      borderRadius: 'var(--radius-2xl)',
      background: 'var(--surface-mint)',
      boxShadow: 'var(--shadow-card)',
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(SparkyMini, {
    size: 56
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 15,
      color: 'var(--mint-700)'
    }
  }, title), score != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-numeric)',
      fontWeight: 700,
      fontSize: 13,
      color: '#fff',
      background: 'var(--brand-primary)',
      borderRadius: 'var(--radius-pill)',
      padding: '2px 10px'
    }
  }, score, "/100")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 17,
      lineHeight: 1.4,
      color: 'var(--text-primary)',
      textWrap: 'pretty'
    }
  }, message)));
}
Object.assign(__ds_scope, { CoachCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brushing/CoachCard.jsx", error: String((e && e.message) || e) }); }

// components/brushing/MouthMap.jsx
try { (() => {
/**
 * MouthMap — the signature Zing component. A stylized dental arch (occlusal
 * view) of 10 zones that fill as the child brushes. This is the design-system
 * recreation of the app's live camera overlay (CLAUDE.md > MouthMap.tsx).
 *
 * Zone states: 'empty' (grey) → 'active' (light mint, brushing now) →
 * 'done' (solid mint + check). At session end, un-brushed zones show 'missed'
 * (warm orange — never red).
 */
const ALL_ZONES = ['top-back-left', 'top-left', 'top-front', 'top-right', 'top-back-right', 'bottom-back-left', 'bottom-left', 'bottom-front', 'bottom-right', 'bottom-back-right'];
const STATE_FILL = {
  empty: 'var(--zone-empty)',
  active: 'var(--zone-active)',
  done: 'var(--zone-done)',
  missed: 'var(--zone-missed)'
};
function polar(cx, cy, r, deg) {
  const a = deg * Math.PI / 180;
  return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
}
function sectorPath(cx, cy, ri, ro, a0, a1) {
  const [x0o, y0o] = polar(cx, cy, ro, a0);
  const [x1o, y1o] = polar(cx, cy, ro, a1);
  const [x1i, y1i] = polar(cx, cy, ri, a1);
  const [x0i, y0i] = polar(cx, cy, ri, a0);
  return `M ${x0o} ${y0o} A ${ro} ${ro} 0 0 1 ${x1o} ${y1o} L ${x1i} ${y1i} A ${ri} ${ri} 0 0 0 ${x0i} ${y0i} Z`;
}
function MouthMap({
  states = {},
  size = 220,
  showLabels = false,
  style = {}
}) {
  const cx = 110,
    cy = 110,
    ro = 96,
    ri = 50;
  // Upper arch across the TOP (angles 200°..340°), lower arch across BOTTOM (20°..160°).
  const upper = ALL_ZONES.slice(0, 5);
  const lower = ALL_ZONES.slice(5);
  const gap = 3; // degrees between teeth

  const buildArc = (zones, startDeg, endDeg) => {
    const span = (endDeg - startDeg) / zones.length;
    return zones.map((z, i) => {
      const a0 = startDeg + i * span + gap / 2;
      const a1 = startDeg + (i + 1) * span - gap / 2;
      const st = states[z] || 'empty';
      const mid = (a0 + a1) / 2;
      const [lx, ly] = polar(cx, cy, (ri + ro) / 2, mid);
      return {
        z,
        a0,
        a1,
        st,
        lx,
        ly
      };
    });
  };
  const segments = [...buildArc(upper, 200, 340), ...buildArc(lower, 20, 160)];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 220 220",
    style: {
      display: 'block',
      ...style
    },
    role: "img",
    "aria-label": "Mouth map"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: ri - 8,
    fill: "var(--surface-mint)"
  }), segments.map(({
    z,
    a0,
    a1,
    st,
    lx,
    ly
  }) => /*#__PURE__*/React.createElement("g", {
    key: z
  }, /*#__PURE__*/React.createElement("path", {
    d: sectorPath(cx, cy, ri, ro, a0, a1),
    fill: STATE_FILL[st],
    stroke: "var(--surface-card)",
    strokeWidth: "2.5",
    style: {
      transition: 'fill var(--dur-base) var(--ease-out)'
    }
  }), st === 'done' && /*#__PURE__*/React.createElement("text", {
    x: lx,
    y: ly + 4,
    textAnchor: "middle",
    fontSize: "13",
    fontWeight: "900",
    fill: "#fff",
    fontFamily: "var(--font-display)"
  }, "\u2713"), st === 'missed' && /*#__PURE__*/React.createElement("text", {
    x: lx,
    y: ly + 4,
    textAnchor: "middle",
    fontSize: "14",
    fontWeight: "900",
    fill: "#fff",
    fontFamily: "var(--font-display)"
  }, "!"), showLabels && /*#__PURE__*/React.createElement("text", {
    x: lx,
    y: ly + 14,
    textAnchor: "middle",
    fontSize: "6",
    fill: "var(--text-tertiary)"
  }, z))));
}
Object.assign(__ds_scope, { ALL_ZONES, MouthMap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brushing/MouthMap.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zing Badge — small status/reward pill. Two looks:
 *  - tone pills for status (mint/sky/sunny/coral/warning/neutral)
 *  - reward badge tiers for kids' achievements.
 */
function Badge({
  children,
  label,
  tone = 'mint',
  icon = null,
  solid = false,
  style = {},
  ...rest
}) {
  const map = {
    mint: ['var(--mint-600)', 'var(--mint-100)', 'var(--mint-500)'],
    sky: ['var(--sky-600)', 'var(--sky-100)', 'var(--sky-400)'],
    sunny: ['#9a7b12', 'var(--sunny-100)', 'var(--sunny-500)'],
    coral: ['#b23a47', 'var(--coral-100)', 'var(--coral-500)'],
    grape: ['#5c4fb5', 'var(--grape-100)', 'var(--grape-500)'],
    warning: ['#9a6418', 'var(--warning-100)', 'var(--warning-500)'],
    neutral: ['var(--ink-600)', 'var(--ink-100)', 'var(--ink-400)']
  };
  const [fg, bg, solidBg] = map[tone] || map.mint;
  const content = children ?? label;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 26,
      padding: '0 12px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 13,
      lineHeight: 1,
      color: solid ? '#fff' : fg,
      background: solid ? solidBg : bg,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon, content);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zing Button — the primary tappable action.
 * Big, pillowy (16px radius), 56px tall, Nunito ExtraBold label.
 * Press = scale 0.96 + slight opacity (touch product). Disabled = 50% opacity.
 */
function Button({
  children,
  label,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  loading = false,
  disabled = false,
  icon = null,
  iconRight = null,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);
  const isDisabled = disabled || loading;
  const content = children ?? label;
  const sizes = {
    sm: {
      height: 44,
      padding: '0 18px',
      font: 15,
      radius: 'var(--radius-md)'
    },
    md: {
      height: 56,
      padding: '0 24px',
      font: 18,
      radius: 'var(--radius-lg)'
    },
    lg: {
      height: 64,
      padding: '0 32px',
      font: 20,
      radius: 'var(--radius-xl)'
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: 'var(--brand-primary)',
      color: 'var(--text-on-brand)',
      boxShadow: pressed ? 'none' : 'var(--shadow-mint)',
      border: 'none'
    },
    secondary: {
      background: 'var(--brand-secondary)',
      color: 'var(--text-on-brand)',
      boxShadow: pressed ? 'none' : 'var(--shadow-sky)',
      border: 'none'
    },
    soft: {
      background: 'var(--surface-mint)',
      color: 'var(--mint-700)',
      boxShadow: 'none',
      border: 'none'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--brand-primary)',
      boxShadow: 'none',
      border: 'none'
    },
    outline: {
      background: 'var(--surface-card)',
      color: 'var(--text-primary)',
      boxShadow: 'none',
      border: '1.5px solid var(--border-subtle)'
    }
  };
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: isDisabled ? undefined : onClick,
    disabled: isDisabled,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      width: fullWidth ? '100%' : 'auto',
      height: s.height,
      padding: s.padding,
      borderRadius: s.radius,
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: s.font,
      lineHeight: 1,
      cursor: isDisabled ? 'not-allowed' : 'pointer',
      opacity: isDisabled ? 0.5 : 1,
      transform: pressed && !isDisabled ? 'scale(0.96)' : 'scale(1)',
      transition: 'transform var(--dur-fast) var(--ease-bounce), box-shadow var(--dur-base) var(--ease-out)',
      WebkitTapHighlightColor: 'transparent',
      ...v,
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement(Spinner, null) : icon, !loading && content, !loading && iconRight);
}
function Spinner() {
  return /*#__PURE__*/React.createElement("span", {
    "aria-label": "loading",
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      border: '2.5px solid rgba(255,255,255,0.45)',
      borderTopColor: '#fff',
      display: 'inline-block',
      animation: 'zing-spin 0.7s linear infinite'
    }
  });
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zing Card — white, pillowy, soft brand-tinted shadow, no hard border.
 * The workhorse container for everything: profiles, sessions, stats.
 */
function Card({
  children,
  tone = 'plain',
  padding = 20,
  radius = 'var(--radius-xl)',
  interactive = false,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);
  const tones = {
    plain: {
      background: 'var(--surface-card)',
      border: 'none'
    },
    mint: {
      background: 'var(--surface-mint)',
      border: 'none'
    },
    sky: {
      background: 'var(--surface-sky)',
      border: 'none'
    },
    sunken: {
      background: 'var(--surface-sunken)',
      border: 'none'
    },
    outline: {
      background: 'var(--surface-card)',
      border: '1.5px solid var(--border-subtle)'
    }
  };
  const t = tones[tone] || tones.plain;
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onPointerDown: () => interactive && setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      borderRadius: radius,
      padding,
      boxShadow: tone === 'sunken' ? 'none' : 'var(--shadow-card)',
      cursor: interactive ? 'pointer' : 'default',
      transform: pressed ? 'scale(0.985)' : 'scale(1)',
      transition: 'transform var(--dur-fast) var(--ease-out)',
      ...t,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zing Chip — a selectable pill, e.g. choosing a child's age or a filter.
 * Big tap target, mint-fill when selected.
 */
function Chip({
  children,
  label,
  selected = false,
  icon = null,
  onClick,
  style = {},
  ...rest
}) {
  const [pressed, setPressed] = React.useState(false);
  const content = children ?? label;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    "aria-pressed": selected,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      minHeight: 44,
      padding: '0 18px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 15,
      cursor: 'pointer',
      color: selected ? 'var(--text-on-brand)' : 'var(--text-primary)',
      background: selected ? 'var(--brand-primary)' : 'var(--surface-card)',
      border: selected ? '1.5px solid var(--brand-primary)' : '1.5px solid var(--border-subtle)',
      boxShadow: selected ? 'var(--shadow-mint)' : 'none',
      transform: pressed ? 'scale(0.95)' : 'scale(1)',
      transition: 'transform var(--dur-fast) var(--ease-bounce), background var(--dur-base), box-shadow var(--dur-base)',
      WebkitTapHighlightColor: 'transparent',
      ...style
    }
  }, rest), icon, content);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Zing Input — mirrors the app's register-screen field: 56px tall, 16px radius,
 * 1.5px subtle border that turns mint on focus / danger on error.
 * Label + optional error message in the brand voice.
 */
function Input({
  label,
  value,
  onChange,
  placeholder = '',
  type = 'text',
  error = '',
  icon = null,
  disabled = false,
  style = {},
  inputStyle = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const borderColor = error ? 'var(--feedback-danger)' : focused ? 'var(--border-focus)' : 'var(--border-subtle)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 56,
      padding: '0 16px',
      borderRadius: 'var(--radius-lg)',
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1.5px solid ${borderColor}`,
      boxShadow: focused && !error ? '0 0 0 4px rgba(0,201,167,0.12)' : 'none',
      transition: 'border-color var(--dur-base), box-shadow var(--dur-base)'
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      display: 'inline-flex',
      fontSize: 20
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    placeholder: placeholder,
    type: type,
    disabled: disabled,
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontWeight: 400,
      fontSize: 16,
      color: 'var(--text-primary)',
      minWidth: 0,
      ...inputStyle
    }
  }, rest))), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--feedback-danger)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/kids/AvatarPicker.jsx
try { (() => {
/**
 * Avatar — a single child's colorful identity circle (an icon on a color).
 * Used standalone (in headers, session screens) and inside AvatarPicker.
 */
const AVATARS = {
  shark: {
    icon: 'ph-fill ph-shark',
    bg: 'var(--sky-400)'
  },
  robot: {
    icon: 'ph-fill ph-robot',
    bg: 'var(--grape-500)'
  },
  rocket: {
    icon: 'ph-fill ph-rocket',
    bg: 'var(--coral-500)'
  },
  cat: {
    icon: 'ph-fill ph-cat',
    bg: 'var(--sunny-500)'
  },
  dog: {
    icon: 'ph-fill ph-dog',
    bg: 'var(--mint-500)'
  },
  butterfly: {
    icon: 'ph-fill ph-butterfly',
    bg: 'var(--sky-500)'
  },
  star: {
    icon: 'ph-fill ph-star',
    bg: 'var(--warning-500)'
  },
  heart: {
    icon: 'ph-fill ph-heart',
    bg: 'var(--coral-500)'
  }
};
const AVATAR_IDS = Object.keys(AVATARS);
function Avatar({
  avatarId = 'dog',
  size = 56,
  ring = false,
  style = {}
}) {
  const a = AVATARS[avatarId] || AVATARS.dog;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-pill)',
      background: a.bg,
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: size * 0.52,
      boxShadow: ring ? '0 0 0 3px var(--surface-card), 0 0 0 6px ' + a.bg : 'var(--shadow-sm)',
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: a.icon
  }));
}

/**
 * AvatarPicker — the child chooses their character during onboarding.
 * A friendly grid of big, tappable avatars; selected one gets a mint ring.
 */
function AvatarPicker({
  value = 'dog',
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14,
      ...style
    }
  }, AVATAR_IDS.map(id => {
    const selected = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      type: "button",
      onClick: () => onChange && onChange(id),
      "aria-pressed": selected,
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 6,
        borderRadius: 'var(--radius-pill)',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        transform: selected ? 'scale(1.06)' : 'scale(1)',
        transition: 'transform var(--dur-base) var(--ease-bounce)',
        WebkitTapHighlightColor: 'transparent'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      avatarId: id,
      size: 62,
      ring: selected
    }));
  }));
}
Object.assign(__ds_scope, { AVATAR_IDS, Avatar, AvatarPicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/kids/AvatarPicker.jsx", error: String((e && e.message) || e) }); }

// components/kids/BadgeCard.jsx
try { (() => {
/**
 * BadgeCard — a kid's achievement reward. Earned = full color + glow;
 * locked = greyed and dimmed. Maps to Badge.type in the data model.
 */
const BADGE_META = {
  streak: {
    icon: 'ph-fill ph-fire',
    color: 'var(--sunny-500)',
    wash: 'var(--sunny-100)',
    label: 'On Fire'
  },
  perfect: {
    icon: 'ph-fill ph-star',
    color: 'var(--mint-500)',
    wash: 'var(--mint-100)',
    label: 'Perfect Brush'
  },
  firstSession: {
    icon: 'ph-fill ph-tooth',
    color: 'var(--sky-400)',
    wash: 'var(--sky-100)',
    label: 'First Brush'
  },
  weeklyGoal: {
    icon: 'ph-fill ph-trophy',
    color: 'var(--grape-500)',
    wash: 'var(--grape-100)',
    label: 'Weekly Star'
  }
};
function BadgeCard({
  type = 'firstSession',
  name,
  earned = true,
  caption = '',
  style = {}
}) {
  const meta = BADGE_META[type] || BADGE_META.firstSession;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      width: 116,
      padding: '18px 12px',
      borderRadius: 'var(--radius-xl)',
      background: 'var(--surface-card)',
      boxShadow: earned ? 'var(--shadow-card)' : 'none',
      border: earned ? 'none' : '1.5px dashed var(--border-strong)',
      opacity: earned ? 1 : 0.6,
      textAlign: 'center',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 'var(--radius-pill)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 34,
      color: earned ? '#fff' : 'var(--ink-400)',
      background: earned ? meta.color : 'var(--ink-100)',
      boxShadow: earned ? 'var(--shadow-sm)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: earned ? meta.icon : 'ph-bold ph-lock-simple'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, name || meta.label), caption && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      color: 'var(--text-secondary)'
    }
  }, caption)));
}
Object.assign(__ds_scope, { BadgeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/kids/BadgeCard.jsx", error: String((e && e.message) || e) }); }

// components/kids/StreakDisplay.jsx
try { (() => {
/**
 * StreakDisplay — the gold flame + day count that drives the daily habit.
 * Sizes: chip (inline), card (hero on the dashboard).
 */
function StreakDisplay({
  days = 0,
  best = null,
  layout = 'card',
  style = {}
}) {
  const flame = /*#__PURE__*/React.createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 2c.6 3.2-1.7 4.6-3 6-1.4 1.5-2.5 3.2-2.5 5.5A5.5 5.5 0 0 0 12 19a5.5 5.5 0 0 0 5.5-5.5c0-1.7-.7-3-1.6-4.2-.5 1-1.3 1.6-2.2 1.7.9-2.4.2-5.6-1.7-9Z",
    fill: "var(--feedback-reward)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 19a3 3 0 0 1-3-3c0-1.4 1-2.4 1.8-3.3.4 1 1.2 1.5 2.2 1.6-.5 1.4-.1 3.2 1 4.2A3 3 0 0 1 12 19Z",
    fill: "#fff",
    opacity: "0.55"
  }));
  if (layout === 'chip') {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 30,
        padding: '0 12px 0 10px',
        borderRadius: 'var(--radius-pill)',
        background: 'var(--sunny-100)',
        color: '#9a7b12',
        fontFamily: 'var(--font-numeric)',
        fontWeight: 700,
        fontSize: 15,
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 18,
        display: 'inline-flex'
      }
    }, flame), days);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: 18,
      borderRadius: 'var(--radius-xl)',
      background: 'linear-gradient(135deg, #FFF7E0, #FFEFC2)',
      boxShadow: 'var(--shadow-card)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 'var(--radius-pill)',
      background: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 30,
      boxShadow: 'var(--shadow-sunny)'
    }
  }, flame), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-numeric)',
      fontWeight: 700,
      fontSize: 32,
      color: '#8a6d10'
    }
  }, days, " ", days === 1 ? 'day' : 'days'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 600,
      fontSize: 14,
      color: '#a9842a'
    }
  }, days > 0 ? 'brushing streak' : 'Start your streak today!', best != null && days > 0 ? `  ·  best ${best}` : '')));
}
Object.assign(__ds_scope, { StreakDisplay });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/kids/StreakDisplay.jsx", error: String((e && e.message) || e) }); }

// guidelines/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "guidelines/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppShell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* global React */
// Zing app shell — iPhone frame, status bar, bottom tab bar, screen router.
(function () {
  const {
    useState,
    useEffect,
    useRef
  } = React;
  function StatusBar({
    dark = false
  }) {
    const color = dark ? '#fff' : 'var(--text-primary)';
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: 50,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        padding: '0 28px 8px',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-numeric)',
        fontWeight: 700,
        fontSize: 15,
        color
      }
    }, "9:41"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 7,
        alignItems: 'center',
        color
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-cell-signal-full",
      style: {
        fontSize: 16
      }
    }), /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-wifi-high",
      style: {
        fontSize: 16
      }
    }), /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-battery-full",
      style: {
        fontSize: 18
      }
    })));
  }
  function TabBar({
    tab,
    onTab
  }) {
    const items = [{
      id: 'home',
      icon: 'house',
      label: 'Home'
    }, {
      id: 'progress',
      icon: 'chart-line-up',
      label: 'Progress'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        height: 88,
        flexShrink: 0,
        background: 'var(--surface-card)',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'flex-start',
        paddingTop: 12,
        boxShadow: '0 -6px 20px rgba(15,32,39,0.04)'
      }
    }, /*#__PURE__*/React.createElement(TabButton, _extends({}, items[0], {
      active: tab === 'home',
      onClick: () => onTab('home')
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => onTab('brush'),
      "aria-label": "Start brushing",
      style: {
        position: 'absolute',
        top: -26,
        width: 66,
        height: 66,
        borderRadius: '50%',
        background: 'var(--brand-primary)',
        border: '4px solid var(--surface-card)',
        cursor: 'pointer',
        boxShadow: 'var(--shadow-mint)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#fff',
        fontSize: 30
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-tooth"
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: 46,
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 11,
        color: 'var(--brand-primary)'
      }
    }, "Brush")), /*#__PURE__*/React.createElement(TabButton, _extends({}, items[1], {
      active: tab === 'progress',
      onClick: () => onTab('progress')
    })));
  }
  function TabButton({
    icon,
    label,
    active,
    onClick
  }) {
    const color = active ? 'var(--brand-primary)' : 'var(--text-tertiary)';
    return /*#__PURE__*/React.createElement("button", {
      onClick: onClick,
      style: {
        flex: 1,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        color
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: `${active ? 'ph-fill' : 'ph-bold'} ph-${icon}`,
      style: {
        fontSize: 25
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 11
      }
    }, label));
  }

  // The phone shell. `chrome` = 'tabs' shows the tab bar; 'none' is full-bleed (session).
  function Phone({
    children,
    chrome = 'tabs',
    tab,
    onTab,
    statusDark = false,
    bg = 'var(--surface-page)'
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 402,
        height: 858,
        borderRadius: 56,
        background: '#0f2027',
        padding: 11,
        boxShadow: '0 40px 90px -30px rgba(15,32,39,0.5)',
        flexShrink: 0,
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        height: '100%',
        borderRadius: 46,
        overflow: 'hidden',
        background: bg,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 12,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 120,
        height: 30,
        background: '#0f2027',
        borderRadius: 18,
        zIndex: 20
      }
    }), /*#__PURE__*/React.createElement(StatusBar, {
      dark: statusDark
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        overflowX: 'hidden',
        position: 'relative'
      }
    }, children), chrome === 'tabs' && /*#__PURE__*/React.createElement(TabBar, {
      tab: tab,
      onTab: onTab
    })));
  }
  window.ZingShell = {
    Phone,
    StatusBar,
    TabBar
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AuthScreens.jsx
try { (() => {
/* global React, ZingDesignSystem_f62470 */
// Welcome + Register + Child setup screens.
(function () {
  const ZDS_auth = window.ZingDesignSystem_f62470;
  const {
    useState
  } = React;
  function WelcomeScreen({
    onStart,
    onLogin
  }) {
    const {
      Button
    } = ZDS_auth;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        background: 'linear-gradient(180deg, var(--surface-mint) 0%, var(--surface-page) 70%)',
        padding: '8px 28px 32px',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/zing-mascot.svg",
      alt: "Sparky",
      style: {
        width: 168,
        marginBottom: 8
      }
    }), /*#__PURE__*/React.createElement("img", {
      src: "../../assets/zing-wordmark.svg",
      alt: "Zing",
      style: {
        height: 56
      }
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 18,
        lineHeight: 1.45,
        color: 'var(--text-secondary)',
        margin: '10px 0 0',
        maxWidth: 280,
        textWrap: 'pretty'
      }
    }, "The brushing buddy that turns two minutes into a daily adventure.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Button, {
      label: "Get started",
      fullWidth: true,
      size: "lg",
      onClick: onStart
    }), /*#__PURE__*/React.createElement(Button, {
      label: "I already have an account",
      variant: "ghost",
      fullWidth: true,
      onClick: onLogin
    })));
  }
  function RegisterScreen({
    onSubmit,
    onBack
  }) {
    const {
      Button,
      Input
    } = ZDS_auth;
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [pw, setPw] = useState('');
    const emailErr = email.length > 0 && !email.includes('@') ? "That email address doesn't look right" : '';
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        padding: '4px 24px 28px'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onBack,
      style: {
        alignSelf: 'flex-start',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        color: 'var(--text-secondary)',
        fontSize: 26,
        marginBottom: 6,
        padding: 4
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-bold ph-arrow-left"
    })), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 30,
        color: 'var(--text-primary)',
        margin: '4px 0 6px'
      }
    }, "Welcome to Zing"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 16,
        color: 'var(--text-secondary)',
        margin: '0 0 22px',
        lineHeight: 1.45
      }
    }, "Create your parent account to start your child's brushing adventure."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Your name",
      value: name,
      onChange: setName,
      placeholder: "e.g. Maria",
      icon: /*#__PURE__*/React.createElement("i", {
        className: "ph-bold ph-user"
      })
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Email",
      value: email,
      onChange: setEmail,
      placeholder: "you@example.com",
      error: emailErr,
      icon: /*#__PURE__*/React.createElement("i", {
        className: "ph-bold ph-envelope-simple"
      })
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Password",
      type: "password",
      value: pw,
      onChange: setPw,
      placeholder: "At least 8 characters",
      icon: /*#__PURE__*/React.createElement("i", {
        className: "ph-bold ph-lock-simple"
      })
    })), /*#__PURE__*/React.createElement(Button, {
      label: "Create account",
      fullWidth: true,
      size: "lg",
      style: {
        marginTop: 20
      },
      onClick: onSubmit
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        textAlign: 'center',
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        color: 'var(--text-secondary)',
        marginTop: 16
      }
    }, "Already have an account? ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-link)',
        fontWeight: 700
      }
    }, "Log in")));
  }
  function ChildSetupScreen({
    onDone
  }) {
    const {
      Button,
      Input,
      Chip,
      AvatarPicker
    } = ZDS_auth;
    const [name, setName] = useState('Leo');
    const [age, setAge] = useState(6);
    const [avatar, setAvatar] = useState('shark');
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        padding: '4px 24px 28px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-numeric)',
        fontWeight: 700,
        fontSize: 12,
        color: 'var(--brand-primary)',
        background: 'var(--surface-mint)',
        padding: '4px 10px',
        borderRadius: 999
      }
    }, "STEP 2 OF 2")), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 28,
        color: 'var(--text-primary)',
        margin: '4px 0 4px'
      }
    }, "Add your child"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 15,
        color: 'var(--text-secondary)',
        margin: '0 0 20px'
      }
    }, "You can add more children later."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 18,
        flex: 1
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Child's name",
      value: name,
      onChange: setName,
      placeholder: "e.g. Leo"
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 14,
        color: 'var(--text-primary)',
        marginBottom: 8
      }
    }, "Age"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        flexWrap: 'wrap'
      }
    }, [4, 5, 6, 7, 8, 9].map(a => /*#__PURE__*/React.createElement(Chip, {
      key: a,
      label: String(a),
      selected: age === a,
      onClick: () => setAge(a)
    })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 14,
        color: 'var(--text-primary)',
        marginBottom: 10
      }
    }, "Pick a character"), /*#__PURE__*/React.createElement(AvatarPicker, {
      value: avatar,
      onChange: setAvatar
    }))), /*#__PURE__*/React.createElement(Button, {
      label: "Start brushing adventure",
      fullWidth: true,
      size: "lg",
      style: {
        marginTop: 22
      },
      onClick: () => onDone({
        name,
        age,
        avatar
      })
    }));
  }
  window.ZingAuth = {
    WelcomeScreen,
    RegisterScreen,
    ChildSetupScreen
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AuthScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Dashboard.jsx
try { (() => {
/* global React, ZingDesignSystem_f62470 */
// Home dashboard + Progress screens.
(function () {
  const ZDS_dash = window.ZingDesignSystem_f62470;
  function SectionTitle({
    children,
    action
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        justifyContent: 'space-between',
        margin: '0 0 12px'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 19,
        color: 'var(--text-primary)',
        margin: 0
      }
    }, children), action);
  }
  function HomeScreen({
    child,
    streak,
    onBrush
  }) {
    const {
      Card,
      Avatar,
      StreakDisplay,
      Badge
    } = ZDS_dash;
    const slots = [{
      label: 'Morning',
      icon: 'sun',
      done: true,
      time: '7:52 AM'
    }, {
      label: 'Evening',
      icon: 'moon',
      done: false,
      time: 'Not yet'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '4px 20px 28px',
        display: 'flex',
        flexDirection: 'column',
        gap: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        color: 'var(--text-secondary)',
        fontWeight: 600
      }
    }, "Good morning,"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 26,
        color: 'var(--text-primary)'
      }
    }, "Maria")), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 44,
        height: 44,
        borderRadius: 999,
        background: 'var(--surface-card)',
        boxShadow: 'var(--shadow-sm)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--text-secondary)',
        fontSize: 22
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-bold ph-gear"
    }))), /*#__PURE__*/React.createElement(Card, {
      tone: "mint",
      padding: 18,
      radius: "var(--radius-2xl)"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      avatarId: child.avatar,
      size: 62
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 20,
        color: 'var(--text-primary)'
      }
    }, child.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 13,
        color: 'var(--text-secondary)',
        fontWeight: 600
      }
    }, "Age ", child.age)), /*#__PURE__*/React.createElement(StreakDisplay, {
      days: streak,
      layout: "chip"
    }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionTitle, null, "Today's brushing"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12
      }
    }, slots.map(s => /*#__PURE__*/React.createElement(Card, {
      key: s.label,
      padding: 16,
      style: {
        flex: 1,
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 44,
        height: 44,
        margin: '0 auto 8px',
        borderRadius: 999,
        background: s.done ? 'var(--surface-mint)' : 'var(--surface-sunken)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 22,
        color: s.done ? 'var(--brand-primary)' : 'var(--text-tertiary)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: `ph-fill ph-${s.done ? 'check-circle' : s.icon}`
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 15,
        color: 'var(--text-primary)'
      }
    }, s.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 12,
        fontWeight: 600,
        color: s.done ? 'var(--mint-600)' : 'var(--text-tertiary)'
      }
    }, s.done ? `Done · ${s.time}` : s.time))))), /*#__PURE__*/React.createElement(Card, {
      padding: 20,
      radius: "var(--radius-2xl)",
      style: {
        background: 'linear-gradient(135deg, #00D7B2, #00A98C)',
        boxShadow: 'var(--shadow-mint)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 20,
        color: '#fff'
      }
    }, "Time to brush!"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        color: 'rgba(255,255,255,0.9)',
        fontWeight: 600,
        marginTop: 2
      }
    }, "Sparky is ready for your evening session.")), /*#__PURE__*/React.createElement("button", {
      onClick: onBrush,
      style: {
        width: 56,
        height: 56,
        borderRadius: 999,
        border: 'none',
        cursor: 'pointer',
        background: '#fff',
        color: 'var(--brand-primary)',
        fontSize: 28,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 6px 16px rgba(0,0,0,0.15)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-play"
    })))));
  }
  function ProgressScreen({
    child,
    streak
  }) {
    const {
      Card,
      StreakDisplay,
      BadgeCard,
      Badge
    } = ZDS_dash;
    const week = [{
      d: 'M',
      done: true
    }, {
      d: 'T',
      done: true
    }, {
      d: 'W',
      done: true
    }, {
      d: 'T',
      done: true
    }, {
      d: 'F',
      done: true
    }, {
      d: 'S',
      done: false
    }, {
      d: 'S',
      done: false
    }];
    const history = [{
      day: 'Today · Morning',
      score: 88,
      tone: 'mint'
    }, {
      day: 'Yesterday · Evening',
      score: 95,
      tone: 'mint'
    }, {
      day: 'Yesterday · Morning',
      score: 72,
      tone: 'warning'
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '4px 20px 28px',
        display: 'flex',
        flexDirection: 'column',
        gap: 22
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 26,
        color: 'var(--text-primary)',
        margin: '4px 0 0'
      }
    }, child.name, "'s progress"), /*#__PURE__*/React.createElement(StreakDisplay, {
      days: streak,
      best: 12
    }), /*#__PURE__*/React.createElement(Card, {
      padding: 18
    }, /*#__PURE__*/React.createElement(SectionTitle, null, "This week"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between'
      }
    }, week.map((w, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 16,
        background: w.done ? 'var(--brand-primary)' : 'var(--surface-sunken)',
        color: w.done ? '#fff' : 'var(--text-tertiary)'
      }
    }, w.done ? /*#__PURE__*/React.createElement("i", {
      className: "ph-bold ph-check"
    }) : null), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 12,
        color: 'var(--text-tertiary)'
      }
    }, w.d))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionTitle, null, "Badges"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        overflowX: 'auto',
        paddingBottom: 4
      }
    }, /*#__PURE__*/React.createElement(BadgeCard, {
      type: "firstSession",
      earned: true,
      caption: "Day 1"
    }), /*#__PURE__*/React.createElement(BadgeCard, {
      type: "streak",
      name: "7-Day Streak",
      earned: true
    }), /*#__PURE__*/React.createElement(BadgeCard, {
      type: "perfect",
      earned: true,
      caption: "95/100"
    }), /*#__PURE__*/React.createElement(BadgeCard, {
      type: "weeklyGoal",
      earned: false
    }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionTitle, null, "Recent sessions"), /*#__PURE__*/React.createElement(Card, {
      padding: 6
    }, history.map((h, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 14px',
        borderBottom: i < history.length - 1 ? '1px solid var(--border-subtle)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 15,
        color: 'var(--text-primary)'
      }
    }, h.day), /*#__PURE__*/React.createElement(Badge, {
      tone: h.tone,
      solid: h.tone === 'mint',
      label: `${h.score}/100`
    }))))));
  }
  window.ZingDashboard = {
    HomeScreen,
    ProgressScreen
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Session.jsx
try { (() => {
/* global React, ZingDesignSystem_f62470 */
// Brushing session (countdown → live) + Results.
(function () {
  const ZDS_sess = window.ZingDesignSystem_f62470;
  const {
    useState,
    useEffect,
    useRef
  } = React;
  const BRUSH_ORDER = ['top-front', 'top-left', 'top-right', 'bottom-front', 'bottom-left', 'bottom-right', 'top-back-right', 'top-back-left']; // leaves bottom-back-left / bottom-back-right un-brushed → "back teeth" coaching
  const ZONE_HINTS = {
    'top-front': 'Brush your top front teeth',
    'top-left': 'Now the top left',
    'top-right': 'Now the top right',
    'bottom-front': 'Down to the bottom front',
    'bottom-left': 'Bottom left now',
    'bottom-right': 'Bottom right — nice!',
    'top-back-right': "Reach the back, you've got this",
    'top-back-left': 'Last few — keep going!'
  };
  function Countdown({
    n
  }) {
    return /*#__PURE__*/React.createElement("div", {
      key: n,
      style: {
        fontFamily: 'var(--font-numeric)',
        fontWeight: 700,
        fontSize: 160,
        color: '#fff',
        lineHeight: 1,
        animation: 'zing-pop 0.6s var(--ease-bounce)'
      }
    }, n);
  }
  function BrushSession({
    child,
    onComplete,
    onCancel
  }) {
    const {
      MouthMap,
      BrushTimer
    } = ZDS_sess;
    const [phase, setPhase] = useState('countdown'); // countdown | active
    const [count, setCount] = useState(3);
    const [remaining, setRemaining] = useState(120);
    const [states, setStates] = useState({});
    const stepRef = useRef(0);

    // Countdown 3-2-1
    useEffect(() => {
      if (phase !== 'countdown') return;
      if (count === 0) {
        setPhase('active');
        return;
      }
      const t = setTimeout(() => setCount(c => c - 1), 800);
      return () => clearTimeout(t);
    }, [phase, count]);

    // Active session — compressed to ~30s for the demo
    useEffect(() => {
      if (phase !== 'active') return;
      const total = 120;
      const tickMs = 250;
      const dec = 1;
      const interval = setInterval(() => {
        setRemaining(r => {
          const next = r - dec;
          // advance brushing progress proportionally
          const elapsed = total - next;
          const idx = Math.floor(elapsed / total * BRUSH_ORDER.length);
          if (idx !== stepRef.current) {
            stepRef.current = idx;
            setStates(prev => {
              const ns = {
                ...prev
              };
              for (let i = 0; i < idx; i++) ns[BRUSH_ORDER[i]] = 'done';
              if (idx < BRUSH_ORDER.length) ns[BRUSH_ORDER[idx]] = 'active';
              return ns;
            });
          }
          if (next <= 0) {
            clearInterval(interval);
            finish();
            return 0;
          }
          return next;
        });
      }, tickMs);
      return () => clearInterval(interval);
      // eslint-disable-next-line
    }, [phase]);
    function finish() {
      const final = {};
      ALL_ZONES_LOCAL.forEach(z => {
        final[z] = 'empty';
      });
      BRUSH_ORDER.forEach(z => {
        final[z] = 'done';
      });
      final['bottom-back-left'] = 'missed';
      final['bottom-back-right'] = 'missed';
      const done = BRUSH_ORDER.length;
      const score = Math.round(done / 10 * 100); // 80
      setTimeout(() => onComplete({
        states: final,
        score,
        missed: ['bottom-back-left', 'bottom-back-right']
      }), 350);
    }
    const ALL_ZONES_LOCAL = ZDS_sess.ALL_ZONES;
    const currentZone = BRUSH_ORDER[Math.min(stepRef.current, BRUSH_ORDER.length - 1)];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'radial-gradient(120% 90% at 50% 0%, #0b3b3a 0%, #07282c 60%, #051c20 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        color: '#fff'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onCancel,
      style: {
        position: 'absolute',
        top: 16,
        right: 20,
        zIndex: 5,
        background: 'rgba(255,255,255,0.14)',
        border: 'none',
        borderRadius: 999,
        width: 40,
        height: 40,
        color: '#fff',
        fontSize: 20,
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: "ph-bold ph-x"
    })), phase === 'countdown' ? /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Countdown, {
      n: count === 0 ? 'Go!' : count
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 17,
        color: 'rgba(255,255,255,0.8)'
      }
    }, "Get your toothbrush ready, ", child.name, "!")) : /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        width: '100%',
        padding: '20px 24px 28px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        background: 'rgba(255,90,95,0.18)',
        color: '#ff8a8d',
        padding: '5px 12px',
        borderRadius: 999,
        fontFamily: 'var(--font-body)',
        fontWeight: 700,
        fontSize: 12,
        marginTop: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: 999,
        background: '#ff5a5f',
        display: 'inline-block'
      }
    }), "CAMERA LIVE \xB7 on-device"), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(MouthMap, {
      states: states,
      size: 260
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 22,
        textAlign: 'center',
        minHeight: 30
      }
    }, ZONE_HINTS[currentZone]), /*#__PURE__*/React.createElement("div", {
      style: {
        margin: '18px 0 8px'
      }
    }, /*#__PURE__*/React.createElement(BrushTimer, {
      remaining: remaining,
      total: 120,
      size: 150,
      style: {
        filter: 'drop-shadow(0 6px 16px rgba(0,201,167,0.4))'
      }
    })), /*#__PURE__*/React.createElement("button", {
      onClick: finish,
      style: {
        background: 'rgba(255,255,255,0.15)',
        border: 'none',
        color: '#fff',
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 15,
        padding: '12px 28px',
        borderRadius: 999,
        cursor: 'pointer'
      }
    }, "I'm done")));
  }
  function ResultsScreen({
    child,
    result,
    onAgain,
    onProgress
  }) {
    const {
      MouthMap,
      CoachCard,
      Button
    } = ZDS_sess;
    const msg = `Awesome job, ${child.name}! Tomorrow, try to reach all the way to your back teeth.`;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100%',
        display: 'flex',
        flexDirection: 'column',
        padding: '8px 24px 28px',
        alignItems: 'center',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 14,
        letterSpacing: '0.08em',
        color: 'var(--brand-primary)',
        marginTop: 6
      }
    }, "SESSION COMPLETE"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-numeric)',
        fontWeight: 700,
        fontSize: 88,
        color: 'var(--text-primary)',
        lineHeight: 1,
        margin: '4px 0'
      }
    }, result.score, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 34,
        color: 'var(--text-tertiary)'
      }
    }, "/100")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 800,
        fontSize: 22,
        color: 'var(--text-primary)'
      }
    }, "Great brushing!"), /*#__PURE__*/React.createElement("div", {
      style: {
        margin: '14px 0 6px'
      }
    }, /*#__PURE__*/React.createElement(MouthMap, {
      states: result.states,
      size: 200
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16,
        marginBottom: 18,
        fontFamily: 'var(--font-body)',
        fontWeight: 600,
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5,
        color: 'var(--text-secondary)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 11,
        height: 11,
        borderRadius: 3,
        background: 'var(--zone-done)'
      }
    }), " Brushed"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5,
        color: 'var(--text-secondary)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 11,
        height: 11,
        borderRadius: 3,
        background: 'var(--zone-missed)'
      }
    }), " Missed")), /*#__PURE__*/React.createElement(CoachCard, {
      score: result.score,
      message: msg,
      style: {
        width: '100%',
        textAlign: 'left'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        width: '100%',
        marginTop: 'auto',
        paddingTop: 22
      }
    }, /*#__PURE__*/React.createElement(Button, {
      label: "See my progress",
      fullWidth: true,
      size: "lg",
      onClick: onProgress
    }), /*#__PURE__*/React.createElement(Button, {
      label: "Brush again",
      variant: "soft",
      fullWidth: true,
      onClick: onAgain
    })));
  }
  window.ZingSession = {
    BrushSession,
    ResultsScreen
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Session.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BrushTimer = __ds_scope.BrushTimer;

__ds_ns.CoachCard = __ds_scope.CoachCard;

__ds_ns.ALL_ZONES = __ds_scope.ALL_ZONES;

__ds_ns.MouthMap = __ds_scope.MouthMap;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.AVATAR_IDS = __ds_scope.AVATAR_IDS;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.AvatarPicker = __ds_scope.AvatarPicker;

__ds_ns.BadgeCard = __ds_scope.BadgeCard;

__ds_ns.StreakDisplay = __ds_scope.StreakDisplay;

})();

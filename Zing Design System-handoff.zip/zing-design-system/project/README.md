# Zing Design System

**Zing** is an iOS-first (Android later) mobile app that uses the phone camera to coach children through proper teeth-brushing in real time. An on-device AI watches the brushing session, maps which zones of the mouth were brushed, and ends with a personalized, kid-friendly coaching message. Streaks, badges and rewards build the daily habit. It is built by a dentist mother and her developer son.

> **Audience:** children ages **4–12** (must work without strong reading skills for the youngest), with **parents** managing accounts. The product must feel playful, simple, safe, and reassuring — never clinical.

This folder is the brand's source of truth for design: color, type, spacing, motion, brand assets, reusable UI components, and a high-fidelity recreation of the app's core screens.

---

## Sources used to build this system

- **GitHub (private):** `danieltwentynine/zing-dental-app-` — React Native + Expo (SDK 56) + NativeWind codebase.
  - `CLAUDE.md` — the canonical product + design brief (palette, type, tone, the Mouth Map spec, the brushing state machine).
  - `tailwind.config.js` — exact brand color + font tokens.
  - `components/ui/Button.tsx`, `SafeScreen.tsx` — the only built primitives so far.
  - `app/(auth)/register.tsx` — the most complete real screen (form patterns, copy voice).
  - `lib/constants.ts` — tooth-zone list + fallback coach messages.
  - `assets/` — Expo placeholder icons only (no real brand mark existed).

  > 🔎 **Explore the repo** to build higher-fidelity work — the codebase is the ground truth for screen logic and the brushing flow: https://github.com/danieltwentynine/zing-dental-app-

The app is at **Phase 1** (foundation): only the parent **register** screen is fully built. Every other screen in the UI kit here is a faithful *forward* recreation built from the detailed specs in `CLAUDE.md` (home dashboard, brushing session, results, progress) — they follow the documented design system, copy voice, and the Mouth Map / state-machine specs, but are design recreations, not 1:1 copies of shipped code (which does not exist yet).

---

## ⚠️ Substitutions & things to confirm

- **No logo or mascot existed** (the repo ships the default Expo placeholder icon). The user explicitly invited ideas, so this system introduces an original **Zing mark** (a friendly tooth + "zing" spark bolt), an **app icon**, a **wordmark**, and a mascot, **"Sparky"** — see `assets/`. **Please review / replace these** if you have brand direction.
- **Icons:** the codebase ships no icon set. This system uses **Phosphor Icons** (rounded/fill weights) from CDN as the closest match to the friendly, chunky aesthetic. Swap if you adopt a different set. See ICONOGRAPHY.
- **Fonts** are the real ones from the app (Nunito, Nunito Sans, Space Grotesk — all Google Fonts), served from the Google CDN. No substitution.

---

## CONTENT FUNDAMENTALS — how Zing writes

There are **two distinct voices**, chosen by who is reading:

**To children — warm, playful, encouraging, never clinical.**
- Second person ("you", "your smile"), present tense, active verbs.
- Celebrates effort and progress, never scolds. A missed zone is an invitation, not a failure: *"Tomorrow, try to reach all the way to your back teeth."*
- Fun analogies for ages 4–7 (sharks, robots, superheroes); slightly more mature for 8–12.
- Exclamation marks used **sparingly** for genuine wins — not on every line. *"You did it!"* / *"Great brushing today!"*
- Never uses clinical/medical language, brand names, or anything that reads as a diagnosis.
- Real examples from the product:
  - *"Great brushing today! Your smile is getting stronger every day."*
  - *"Awesome job! Tomorrow, try to reach all the way to your back teeth."*
  - *"You did it! Keep brushing every day and your teeth will sparkle."*
  - *"You missed your back teeth!"* (the canonical coaching callout)
  - *"Don't forget your top teeth!"* (live zone alert — gentle, never alarming)

**To parents — clear, reassuring, lightly warm, professional.**
- Plain, calm, trustworthy. Privacy and safety are foregrounded.
- *"Create your parent account to start your child's brushing adventure."*
- *"Welcome to Zing"* / *"Welcome back"*
- Friendly, specific error help instead of codes: *"This email is already registered. Try logging in instead."*, *"No connection. Please check your internet and try again."*

**Button & label rules (both voices):**
- Always **contextual, active-verb** labels — *"Start brushing"*, *"See results"*, *"Try again"*, *"Create account"*, *"Log in"*.
- **Never** generic labels: no *"Submit"*, *"OK"*, *"Cancel"*.
- Field labels are short and human: *"Your name"*, *"Email"*, *"Confirm password"*; placeholders show real-feeling examples (*"e.g. Maria"*, *"you@example.com"*).

**Casing & punctuation:** Sentence case everywhere (headings, buttons, labels). No ALL-CAPS shouting except tiny eyebrow/meta labels. **No emoji in product copy** — playfulness comes from the mascot, color, and motion, not emoji. Numbers (scores, streaks, timers) are set in the numeric typeface for a confident, game-like feel.

**The vibe:** a cheerful brushing *adventure* — a friendly coach in your pocket. Safe, simple, a little bit of a game. Calm for parents, delightful for kids.

---

## VISUAL FOUNDATIONS

**Overall feeling:** bright, clean, pillowy, optimistic. Lots of white/near-white space, two confident brand hues (mint + sky), generous rounding, soft tinted shadows, springy motion. A "fresh and minty clean" feeling that maps directly to the product promise.

**Color** — see `tokens/colors.css`.
- **Mint `#00C9A7`** is the hero: primary CTAs, brand mark, and every "success / brushed / done" state.
- **Sky `#4FC3F7`** is the supporting hue: progress, secondary actions, info.
- Backgrounds are **near-white with a mint whisper** (`#F8FFFE`); cards are pure white. Soft mint/sky *washes* (`--surface-mint`, `--surface-sky`) zone off hero areas — used as flat fills, **not** heavy gradients.
- **Warm orange `#FFB347`** is the *only* "attention" color shown to children (missed zones, "try again") — **red is never shown to a child**; `--danger-500` is reserved for parent-facing auth errors.
- Playful accents (sunny gold, coral, grape) appear in avatars, badge tiers, and celebration — used as small pops, never as large fields.
- **Imagery vibe:** warm, bright, high-key, friendly. No grain, no moody/cool desaturation, no black-and-white.

**Type** — see `tokens/typography.css`. Display = **Nunito ExtraBold (800)** (rounded, friendly); body = **Nunito Sans** (400/600); numbers = **Space Grotesk Bold (700)**. The scale is generous and chunky — minimum body 16px; headings are big and rounded. Tight tracking on big display, normal on body.

**Spacing & layout** — 4px grid (`tokens/spacing.css`). Mobile gutter is 24px. **Touch targets never below 48px** (kids' fingers); the standard control height is 56px. Layouts are single-column, vertically rhythmic, with a fixed bottom tab bar and occasional fixed primary CTA.

**Corner radii** — big and soft (`tokens/effects.css`). The workhorse is **16px (`--radius-lg`, "rounded-2xl")** on buttons, inputs and cards; hero cards and sheets go to 24–32px; chips/avatars/streak capsules are full pills.

**Cards** — white fill, 16–24px radius, **soft low brand-tinted shadow** (`--shadow-card`, never a hard black drop-shadow), usually no border (or a hairline `--border-subtle` when on white). Elevation comes from shadow, not strokes.

**Shadows** — soft, low, **tinted toward ink/brand, never pure black**. Primary CTAs and "live" elements get a colored **glow** (`--shadow-mint` / `--shadow-sky` / `--shadow-sunny`).

**Borders** — mostly borderless; inputs use a 1.5px `--border-subtle` that turns **mint on focus** (and `--danger` on error). No heavy outlines.

**Backgrounds** — flat tinted fills and soft washes; **no busy patterns, no photographic hero backgrounds, no aggressive gradients.** The mascot and rounded shapes carry the personality.

**Motion** — springy and friendly. Use `--ease-bounce` (overshoot pop) for rewards, badge reveals, and the countdown; `--ease-out` for everyday transitions. Press feedback is a gentle **scale-down to 0.96** plus slight opacity, *not* a color flash. Mouth-map zones fill **smoothly, no harsh flickers**. Celebrations (badge earned, streak up) may bounce; nothing decorative loops forever during a brushing session.

**Hover/press states** — this is a touch product: **press** = `active:opacity-80` and/or scale-to-0.96; disabled = `opacity-50`. On web previews, hover mirrors the press treatment subtly.

**Transparency & blur** — used lightly: the camera-overlay scrim and modal backdrops use a soft ink veil; sparingly elsewhere. No heavy glassmorphism.

---

## ICONOGRAPHY

The Zing codebase ships **no icon set** of its own (only app launcher icons). For this design system we standardize on **[Phosphor Icons](https://phosphoricons.com/)** — its **bold** and **fill** weights with rounded terminals are the closest match to Zing's chunky, friendly, rounded aesthetic (Nunito's roundness, pillowy cards). This is a **substitution — confirm or replace.**

- **Style rule:** prefer Phosphor **bold** (≈2px-equivalent, rounded) for line icons and **fill** for active tab-bar items and playful spot icons. Keep icons at 24px in UI, 20px inline, 48px for hero/empty-state.
- **Color:** icons inherit text color (`--text-secondary` at rest, `--brand-primary` when active/selected). Reward/streak icons use `--feedback-reward` (gold).
- **Load from CDN:** `<script src="https://unpkg.com/@phosphor-icons/web@2.1.1"></script>` then `<i class="ph-bold ph-tooth"></i>` / `<i class="ph-fill ph-star"></i>`.
- **Emoji:** **not** used in product copy or as UI icons. Personality comes from the mascot, color and motion.
- **Unicode glyphs:** not used as icons.
- **Brand glyphs / illustration:** the **Zing mark** (tooth + spark) and the **Sparky** mascot are bespoke SVGs in `assets/` — use these for splash, empty states, rewards and onboarding, rather than drawing new ones.

Brand assets in `assets/`:
- `zing-mark.svg` — the tooth + spark glyph (mint, transparent bg).
- `zing-icon.svg` — app-icon lockup (white tooth on a mint squircle, knocked-out bolt).
- `zing-wordmark.svg` / `zing-wordmark-light.svg` — mark + "Zing" wordmark in Nunito ExtraBold (dark + reversed-for-dark-bg).
- `zing-mascot.svg` — **Sparky** hero pose (holding a toothbrush) — brushing & coaching.
- `sparky-cheer.svg` — Sparky celebrating (arms up) — rewards, streaks, "perfect" moments.
- `sparky-wave.svg` — Sparky waving — onboarding & empty states.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (import-only). Consumers link this.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css`.
- `assets/` — brand mark, icon, wordmark, mascot (+ imported Expo launcher icons).
- `README.md` — this file. `SKILL.md` — Agent-Skills entry point.

**Foundation cards** (Design System tab) — `guidelines/` : color, type, spacing, radius, shadow, motion, brand specimens.

**Components** (`window.ZingDesignSystem_f62470`) — `components/`:
- `core/` — **Button**, **Card**, **Badge**, **Chip**
- `forms/` — **Input**
- `kids/` — **StreakDisplay**, **BadgeCard**, **AvatarPicker**
- `brushing/` — **MouthMap**, **BrushTimer**, **CoachCard**

**UI kit** — `ui_kits/app/` : the Zing mobile app — onboarding, register, home dashboard, live brushing session, results, progress. Open `ui_kits/app/index.html` for the interactive click-through.

---

*Built from the `zing-dental-app-` repo. Explore that repository to design with higher fidelity against the real screens and brushing flow.*
